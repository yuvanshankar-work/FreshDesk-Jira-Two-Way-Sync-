import { describe, it, expect, vi } from 'vitest';

global.renderData = vi.fn();
global.$request = {
  invokeTemplate: vi.fn().mockResolvedValue({ response: '{}' })
};

const server = require('../server/server.js');
const { handleResponse } = require('../server/lib/handle-response.js');

describe('Server handlers exports', () => {
  it('exports all expected event handlers', () => {
    expect(typeof server.onTicketCreateHandler).toBe('function');
    expect(typeof server.onTicketUpdateHandler).toBe('function');
    expect(typeof server.onConversationCreateHandler).toBe('function');
    expect(typeof server.onExternalEventHandler).toBe('function');
    expect(typeof server.onAppInstallHandler).toBe('function');
    expect(typeof server.onAppUninstallHandler).toBe('function');
  });

  it('runs onAppUninstallHandler without errors', () => {
    expect(() => server.onAppUninstallHandler({ iparams: {} })).not.toThrow();
  });
});

describe('handleResponse helper', () => {
  it('handles successful response with 200 status', () => {
    const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    handleResponse(null, { statusCode: 200 });
    expect(consoleSpy).toHaveBeenCalledWith(
      JSON.stringify({ status: 200, message: 'success' })
    );
    consoleSpy.mockRestore();
  });

  it('ignores response when error is present', () => {
    const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    handleResponse(new Error('Network error'), { statusCode: 200 });
    expect(consoleSpy).not.toHaveBeenCalled();
    consoleSpy.mockRestore();
  });

  it('ignores response when statusCode is not 200', () => {
    const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    handleResponse(null, { statusCode: 404 });
    expect(consoleSpy).not.toHaveBeenCalled();
    consoleSpy.mockRestore();
  });
});
