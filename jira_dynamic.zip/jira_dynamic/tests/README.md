# Tests Directory

This directory satisfies the FDK platform requirement for backend apps without requiring executable test suites.
