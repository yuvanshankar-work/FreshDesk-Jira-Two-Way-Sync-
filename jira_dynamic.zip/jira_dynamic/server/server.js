const SafeBuffer = (typeof global !== "undefined" && global.Buffer) || (typeof Buffer !== "undefined" && Buffer) || require("buffer").Buffer;
const axios = require("axios").default || require("axios");

if (typeof global.Buffer === "undefined") {
  global.Buffer = SafeBuffer;
}
if (typeof globalThis.Buffer === "undefined") {
  globalThis.Buffer = SafeBuffer;
}

let JIRA_DOMAIN = "";
let JIRA_AUTH = "";
let FRESHDESK_DOMAIN = "";
let FRESHDESK_AUTH = "";
let JIRA_USER_EMAIL = "";


function buildBasicAuth(user, secret) {
  return "Basic " + SafeBuffer.from(user + ":" + secret).toString("base64");
}

function sanitizeDomain(domain) {
  if (typeof domain !== "string") return "";
  return domain
    .trim()
    .replace(/^https?:\/\//i, "")
    .replace(/\/+$/, "");
}

function initJiraAuth(iparams) {
  JIRA_DOMAIN = sanitizeDomain(iparams.jira_domain);
  JIRA_USER_EMAIL = typeof iparams.jira_email === "string" ? iparams.jira_email.trim() : "";
  if (JIRA_USER_EMAIL && iparams.jira_api_token) {
    const token = typeof iparams.jira_api_token === "string" ? iparams.jira_api_token.trim() : iparams.jira_api_token;
    JIRA_AUTH = buildBasicAuth(JIRA_USER_EMAIL, token);
  }
}

function initFreshdeskAuth(iparams) {
  FRESHDESK_DOMAIN = sanitizeDomain(iparams.freshdesk_domain);
  if (iparams.freshdesk_api_key) {
    const key = typeof iparams.freshdesk_api_key === "string" ? iparams.freshdesk_api_key.trim() : iparams.freshdesk_api_key;
    FRESHDESK_AUTH = buildBasicAuth(key, "X");
  }
}

function sanitizeIparams(iparams) {
  if (!iparams) return {};
  if (iparams.jira_domain) iparams.jira_domain = sanitizeDomain(iparams.jira_domain);
  if (iparams.freshdesk_domain) iparams.freshdesk_domain = sanitizeDomain(iparams.freshdesk_domain);
  if (typeof iparams.jira_email === "string") iparams.jira_email = iparams.jira_email.trim();
  return iparams;
}

function initCredentials(args) {
  const iparams = sanitizeIparams(args ? args.iparams : null);
  initJiraAuth(iparams);
  initFreshdeskAuth(iparams);
  initProjectFields(iparams);
  initFreshdeskFields(iparams);
  initStatusMapping(iparams);
  initPriorityConfig(iparams);
  initGeneralSettings(iparams);
  initTextLabels(iparams);
  JIRA_ISSUE_TYPE = iparams.jira_issue_type || "Task";
  DEFAULT_JIRA_PROJECT = iparams.jira_project || "HL";
}

// ---------- Instance settings loaded from the installation page ----------

let PROJECT_CUSTOM_FIELDS = {};
let FD_FIELDS = { names: {}, syncFields: {} };

// Only these are mandatory per project; every other field is optional
const REQUIRED_FIELD_KEYS = ["ticketId", "syncToFreshDesk"];

function isValidFieldSpec(spec) {
  return Boolean(spec) && /^customfield_\d+$/.test(String(spec.id));
}

function isValidProjectConfig(config) {
  return Boolean(config) && REQUIRED_FIELD_KEYS.every((key) => isValidFieldSpec(config[key]));
}

function parseJsonSetting(text, label) {
  if (typeof text === "object" && text !== null) return text;
  try {
    return JSON.parse(text);
  } catch (err) {
    console.log(label + " setting is missing or not valid JSON:", err.message);
    return null;
  }
}

// "OINFO": "IHL" means: reuse the IHL field IDs
function resolveFieldAliases(raw) {
  const resolved = {};
  for (const [key, value] of Object.entries(raw)) {
    resolved[key.toUpperCase()] = typeof value === "string" ? raw[value] : value;
  }
  return resolved;
}

function buildProjectFieldMap(raw) {
  const map = {};
  for (const [project, config] of Object.entries(resolveFieldAliases(raw))) {
    if (isValidProjectConfig(config)) {
      map[project] = config;
    } else {
      console.log("Skipping project with missing or invalid field config:", project);
    }
  }
  return map;
}

function initProjectFields(iparams) {
  const raw = parseJsonSetting(iparams.project_custom_fields, "project_custom_fields");
  PROJECT_CUSTOM_FIELDS = raw ? buildProjectFieldMap(raw) : {};
}

function asNameList(value) {
  if (Array.isArray(value)) return value.filter(Boolean);
  return value ? [value] : [];
}

// "cf_x" or { read: [...], write: "cf_x" }  ->  { read: [...], write: "cf_x" }
function toFieldNames(entry) {
  if (typeof entry === "string") return { read: [entry], write: entry };
  const cfg = entry || {};
  const read = asNameList(cfg.read);
  const write = cfg.write || read[0] || "";
  return { read: read.length ? read : asNameList(write), write };
}

function buildFdNameMap(raw) {
  const names = {};
  for (const [key, entry] of Object.entries(raw)) {
    if (key !== "syncFields") names[key] = toFieldNames(entry);
  }
  return names;
}

function buildSyncFieldMap(raw) {
  const sync = {};
  for (const [key, name] of Object.entries(raw.syncFields || {})) {
    if (typeof name === "string" && name) sync[key] = name;
  }
  return sync;
}

function initFreshdeskFields(iparams) {
  const raw = parseJsonSetting(iparams.freshdesk_fields, "freshdesk_fields");
  FD_FIELDS = raw ? { names: buildFdNameMap(raw), syncFields: buildSyncFieldMap(raw) } : { names: {}, syncFields: {} };
}

function matchFieldKey(actualKey, searchKey) {
  const cleanActual = actualKey.replace(/_\d+$/, "");
  const cleanSearch = searchKey.replace(/_\d+$/, "");
  if (cleanActual === cleanSearch) return true;
  const normActual = cleanActual.replace(/[^a-z0-9]/gi, "").toLowerCase();
  const normSearch = cleanSearch.replace(/[^a-z0-9]/gi, "").toLowerCase();
  return normActual === normSearch;
}

// Helper: dynamically find custom field value handling account ID suffix (e.g. _5061501) and formatting differences
function findCustomFieldValue(customFields, key) {
  if (!customFields || !key) return "";
  if (hasValue(customFields[key])) return String(customFields[key]);
  for (const [k, v] of Object.entries(customFields)) {
    if (matchFieldKey(k, key) && hasValue(v)) {
      return String(v);
    }
  }
  return "";
}

// First non-empty value among the configured Freshdesk field names
function readFdField(customFields, key) {
  const entry = FD_FIELDS.names[key];
  if (!entry || !customFields) return "";
  for (const name of entry.read) {
    const val = findCustomFieldValue(customFields, name);
    if (hasValue(val)) return val;
  }
  return "";
}

function writeFdField(key) {
  const entry = FD_FIELDS.names[key];
  return entry ? entry.write : "";
}


// Fields copied between Freshdesk and Jira for one project: [{ key, fdName, spec }]
function activeSyncFields(fieldConfig) {
  return Object.entries(FD_FIELDS.syncFields)
    .filter(([key]) => isValidFieldSpec(fieldConfig[key]))
    .map(([key, fdName]) => ({ key, fdName, spec: fieldConfig[key] }));
}

function readSyncFieldsFromJira(jiraFields, fieldConfig) {
  const raw = {};
  for (const item of activeSyncFields(fieldConfig)) {
    raw[item.fdName] = readJiraField(jiraFields, item.spec);
  }
  return raw;
}


function buildRawFreshdeskFields(jiraFields, fieldConfig) {
  return readSyncFieldsFromJira(jiraFields, fieldConfig);
}

function isMeaningfulJiraValue(val) {
  if (val === null || val === undefined || val === "") return false;
  if (Array.isArray(val) && val.length === 0) return false;
  return true;
}

function buildJiraSyncFieldValues(customFields, fieldConfig) {
  const values = {};
  for (const item of activeSyncFields(fieldConfig)) {
    const rawVal = getFieldValue(customFields, item.fdName);
    const formatted = formatFieldValueForJira(item.spec, rawVal);
    if (isMeaningfulJiraValue(formatted)) {
      values[item.spec.id] = formatted;
    }
  }
  return values;
}

function buildJiraLinkFields(issueUrl, issueKey, issueId) {
  const values = { jiraIssueUrl: issueUrl, jiraIssueKey: issueKey, jiraIssueId: issueId ? String(issueId) : "" };
  const fields = {};
  for (const [key, value] of Object.entries(values)) {
    const name = writeFdField(key);
    if (name && value) fields[name] = value;
  }
  return fields;
}

// ---------- Jira search by Freshdesk ticket ID (built from the same settings) ----------

function cfNumber(fieldId) {
  return String(fieldId).replace("customfield_", "");
}

function jqlClauseFor(fieldId, type, ticketId) {
  const cf = `cf[${cfNumber(fieldId)}]`;
  return type === "number" ? `${cf} = ${ticketId}` : `${cf} ~ "${ticketId}"`;
}

function collectProjectTicketIdClauses(ticketId, config) {
  const clauses = new Set();
  if (config && config.ticketId && config.ticketId.id) {
    clauses.add(jqlClauseFor(config.ticketId.id, config.ticketId.type, ticketId));
  }
  if (config && config.freshdeskId) {
    clauses.add(jqlClauseFor(config.freshdeskId, "string", ticketId));
  }
  return [...clauses];
}

function collectTicketIdClauses(ticketId) {
  const clauses = new Set();
  for (const config of Object.values(PROJECT_CUSTOM_FIELDS)) {
    for (const clause of collectProjectTicketIdClauses(ticketId, config)) {
      clauses.add(clause);
    }
  }
  return [...clauses];
}

function formatProjectJql(normKey, ticketId, recent) {
  const config = PROJECT_CUSTOM_FIELDS[normKey];
  const projectClauses = collectProjectTicketIdClauses(ticketId, config);
  if (projectClauses.length > 0) {
    return `project = "${normKey}" and (${projectClauses.join(" or ")})${recent} order by created desc`;
  }
  return `project = "${normKey}"${recent} order by created desc`;
}

function buildTicketIdJql(ticketId, projectKey, recentOnly = false) {
  const normKey = typeof projectKey === "string" ? projectKey.trim().toUpperCase() : "";
  const recent = recentOnly ? ' and created >= "-2h"' : "";
  if (normKey && PROJECT_CUSTOM_FIELDS[normKey]) {
    return formatProjectJql(normKey, ticketId, recent);
  }
  const all = collectTicketIdClauses(ticketId).join(" or ");
  return all ? `(${all})${recent} order by created desc` : "";
}

const PRIORITY_MAP = {
  1: "Low",
  2: "Medium",
  3: "High",
  4: "Urgent"
};

const REVERSE_PRIORITY_MAP = {
  "Low": 1,
  "Medium": 2,
  "High": 3,
  "Urgent": 4
};

// ---------- Status mapping loaded from the installation page ----------

let STATUS_CONFIG = { freshdeskToJira: {}, jiraToFreshdesk: {}, aliases: {} };

function buildFdToJiraMap(raw) {
  const map = {};
  for (const [id, name] of Object.entries(raw || {})) {
    if (typeof name === "string" && name.trim()) map[String(id).trim()] = name.trim();
  }
  return map;
}

// Reverse of freshdeskToJira, plus any extra Jira names from jiraToFreshdesk
function buildJiraToFdMap(fdToJira, extra) {
  const map = {};
  for (const [id, name] of Object.entries(fdToJira)) {
    map[name] = Number(id);
  }
  for (const [name, id] of Object.entries(extra || {})) {
    if (name && !isNaN(Number(id))) map[name.trim()] = Number(id);
  }
  return map;
}

function buildStatusAliasMap(raw) {
  const map = {};
  for (const [key, list] of Object.entries(raw || {})) {
    map[key.toLowerCase()] = asNameList(list).map((v) => String(v).toLowerCase());
  }
  return map;
}

function initStatusMapping(iparams) {
  const raw = parseJsonSetting(iparams.status_mapping, "status_mapping");
  if (!raw) {
    STATUS_CONFIG = { freshdeskToJira: {}, jiraToFreshdesk: {}, aliases: {} };
    return;
  }
  const freshdeskToJira = buildFdToJiraMap(raw.freshdeskToJira);
  STATUS_CONFIG = {
    freshdeskToJira,
    jiraToFreshdesk: buildJiraToFdMap(freshdeskToJira, raw.jiraToFreshdesk),
    aliases: buildStatusAliasMap(raw.aliases)
  };
}

// ---------- Configurable defaults & settings loaded from iparams ----------

const DEFAULT_PRIORITY_CONFIG = {
  freshdeskToJira: PRIORITY_MAP,
  jiraToFreshdesk: {},
  defaultJiraPriority: "Medium",
  defaultFreshdeskPriority: 2
};

const DEFAULT_GENERAL_SETTINGS = {
  syncToggle: { writeYesValue: "Yes", yesValues: ["yes"], noValues: ["no"] },
  defaultFreshdeskStatusId: 2,
  skipTransitionOnCreateStatuses: ["Nový"],
  maxAttachmentMb: 20,
  attachmentDelayMs: 3000,
  commentRetryAttempts: 3,
  commentRetryBackoffMs: 2000
};

const DEFAULT_TEXT_LABELS = {
  freshdeskCommentPrefix: "Freshdesk",
  jiraCommentPrefix: "Jira Comment",
  privateNote: "Private Note",
  customerReply: "Customer Reply",
  publicNote: "Public Note",
  unknownAuthor: "User",
  unknownJiraAuthor: "Jira User",
  attachedFileText: "Please find the attached {type} ({name}).",
  attachedFromJira: "📎 Attached from Jira: {names}",
  notTransferred: "⚠️ Not transferred (too large or failed): {names}",
  defaultSummary: "Jira Task {key}",
  fileTypes: {
    pdf: "PDF",
    png: "image",
    jpg: "image",
    jpeg: "image",
    gif: "image",
    bmp: "image",
    webp: "image",
    svg: "image",
    doc: "document",
    docx: "document",
    xls: "spreadsheet",
    xlsx: "spreadsheet",
    csv: "spreadsheet",
    default: "file"
  }
};

let PRIORITY_CONFIG = {
  ...DEFAULT_PRIORITY_CONFIG,
  reverseMap: REVERSE_PRIORITY_MAP
};

let GENERAL_SETTINGS = {
  ...DEFAULT_GENERAL_SETTINGS,
  syncToggle: {
    ...DEFAULT_GENERAL_SETTINGS.syncToggle,
    yesValues: DEFAULT_GENERAL_SETTINGS.syncToggle.yesValues.map((v) => v.toLowerCase()),
    noValues: DEFAULT_GENERAL_SETTINGS.syncToggle.noValues.map((v) => v.toLowerCase())
  },
  skipTransitionOnCreateStatuses: DEFAULT_GENERAL_SETTINGS.skipTransitionOnCreateStatuses.map((v) => v.toLowerCase())
};

let TEXT_LABELS = {
  ...DEFAULT_TEXT_LABELS,
  fileTypes: { ...DEFAULT_TEXT_LABELS.fileTypes }
};

let JIRA_ISSUE_TYPE = "Task";
let DEFAULT_JIRA_PROJECT = "HL";

function fillTemplate(text, values) {
  if (!text || typeof text !== "string") return "";
  return text.replace(/\{(\w+)\}/g, (match, key) => {
    return (values && values[key] !== undefined) ? String(values[key]) : match;
  });
}

function lookupReversePriority(name) {
  if (!name) return null;
  const trimmed = String(name).trim();
  const map = (PRIORITY_CONFIG && PRIORITY_CONFIG.reverseMap) || REVERSE_PRIORITY_MAP;
  if (map[trimmed] !== undefined) return map[trimmed];
  const lower = trimmed.toLowerCase();
  for (const [pName, id] of Object.entries(map)) {
    if (pName.toLowerCase() === lower) return id;
  }
  return null;
}

function initPriorityConfig(iparams) {
  const raw = parseJsonSetting(iparams.priority_mapping, "priority_mapping");
  if (!raw) {
    const freshdeskToJira = DEFAULT_PRIORITY_CONFIG.freshdeskToJira;
    PRIORITY_CONFIG = {
      ...DEFAULT_PRIORITY_CONFIG,
      freshdeskToJira,
      reverseMap: buildJiraToFdMap(freshdeskToJira, DEFAULT_PRIORITY_CONFIG.jiraToFreshdesk)
    };
    return;
  }
  const freshdeskToJira = {
    ...DEFAULT_PRIORITY_CONFIG.freshdeskToJira,
    ...(raw.freshdeskToJira || {})
  };
  const extra = raw.jiraToFreshdesk || DEFAULT_PRIORITY_CONFIG.jiraToFreshdesk;
  PRIORITY_CONFIG = {
    freshdeskToJira,
    jiraToFreshdesk: extra,
    defaultJiraPriority: raw.defaultJiraPriority || DEFAULT_PRIORITY_CONFIG.defaultJiraPriority,
    defaultFreshdeskPriority: raw.defaultFreshdeskPriority !== undefined ? Number(raw.defaultFreshdeskPriority) : DEFAULT_PRIORITY_CONFIG.defaultFreshdeskPriority,
    reverseMap: buildJiraToFdMap(freshdeskToJira, extra)
  };
}

function buildSyncToggleConfig(raw) {
  const src = raw || {};
  const def = DEFAULT_GENERAL_SETTINGS.syncToggle;
  return {
    writeYesValue: src.writeYesValue || def.writeYesValue,
    yesValues: asNameList(src.yesValues || def.yesValues).map((v) => String(v).toLowerCase()),
    noValues: asNameList(src.noValues || def.noValues).map((v) => String(v).toLowerCase())
  };
}

function readSettingNum(val, fallback) {
  return (val !== undefined && !isNaN(Number(val))) ? Number(val) : fallback;
}

function initGeneralSettings(iparams) {
  const raw = parseJsonSetting(iparams.general_settings, "general_settings");
  if (!raw) {
    GENERAL_SETTINGS = { ...DEFAULT_GENERAL_SETTINGS };
    return;
  }
  const skipList = raw.skipTransitionOnCreateStatuses || DEFAULT_GENERAL_SETTINGS.skipTransitionOnCreateStatuses;
  GENERAL_SETTINGS = {
    syncToggle: buildSyncToggleConfig(raw.syncToggle),
    defaultFreshdeskStatusId: readSettingNum(raw.defaultFreshdeskStatusId, DEFAULT_GENERAL_SETTINGS.defaultFreshdeskStatusId),
    skipTransitionOnCreateStatuses: asNameList(skipList).map((v) => String(v).toLowerCase()),
    maxAttachmentMb: readSettingNum(raw.maxAttachmentMb, DEFAULT_GENERAL_SETTINGS.maxAttachmentMb),
    attachmentDelayMs: readSettingNum(raw.attachmentDelayMs, DEFAULT_GENERAL_SETTINGS.attachmentDelayMs),
    commentRetryAttempts: readSettingNum(raw.commentRetryAttempts, DEFAULT_GENERAL_SETTINGS.commentRetryAttempts),
    commentRetryBackoffMs: readSettingNum(raw.commentRetryBackoffMs, DEFAULT_GENERAL_SETTINGS.commentRetryBackoffMs)
  };
}

function initTextLabels(iparams) {
  const raw = parseJsonSetting(iparams.text_labels, "text_labels");
  const src = raw || {};
  const fileTypes = {
    ...DEFAULT_TEXT_LABELS.fileTypes,
    ...(src.fileTypes || {})
  };
  TEXT_LABELS = {
    ...DEFAULT_TEXT_LABELS,
    ...src,
    fileTypes
  };
}

// Freshdesk status ID -> Jira status name (null if not mapped)
function getJiraStatusName(statusId) {
  const map = STATUS_CONFIG.freshdeskToJira;
  const numId = parseInt(statusId, 10);
  return map[String(numId)] || map[String(statusId)] || null;
}

function getFieldValue(customFields, key) {
  try {
    return findCustomFieldValue(customFields, key);
  } catch (error) {
    console.error("Error getting field value", error);
    return "";
  }
}


function getProjectKeyFromIssueKey(issueKey) {
  console.log("getProjectKeyFromIssueKey", issueKey);
  if (typeof issueKey !== "string") return "";
  const parts = issueKey.split("-");
  const prefix = parts[0].toUpperCase();
  return PROJECT_CUSTOM_FIELDS[prefix] ? prefix : "";
}

function resolveNormalizedProject(val) {
  if (!val) return "";
  const norm = String(val).trim().toUpperCase();
  return PROJECT_CUSTOM_FIELDS[norm] ? norm : "";
}

function getProjectKey(customFields, issueKey) {
  console.log("getProjectKey", customFields, issueKey);
  const fromIssue = getProjectKeyFromIssueKey(issueKey);
  if (fromIssue) return fromIssue;
  const fromField = resolveNormalizedProject(readFdField(customFields, "jiraProject"));
  if (fromField) return fromField;
  return resolveNormalizedProject(DEFAULT_JIRA_PROJECT);
}

function getIssueKey(customFields) {
  console.log("getIssueKey", customFields);
  if (!customFields) return "";
  return readFdField(customFields, "jiraIssueKey");
}

function formatLabelsValue(val, isClear) {
  if (isClear) return [];
  return Array.isArray(val) ? val : [String(val)];
}

function formatNonLabelValue(type, val) {
  if (type === "select") {
    return typeof val === "object" && val ? val : { value: String(val) };
  }
  if (type === "number") {
    const num = Number(val);
    return isNaN(num) ? null : num;
  }
  return String(val);
}

function formatFieldValueForJira(fieldSpec, val) {
  if (!fieldSpec) return val;
  const isClear = !hasValue(val);
  if (fieldSpec.type === "labels") {
    return formatLabelsValue(val, isClear);
  }
  if (isClear) return null;
  return formatNonLabelValue(fieldSpec.type, val);
}

function formatTicketId(fieldSpec, id) {
  if (fieldSpec.type === "number") {
    return Number(id);
  }
  return String(id);
}

function getPriorityName(priority) {
  const map = (PRIORITY_CONFIG && PRIORITY_CONFIG.freshdeskToJira) || {};
  return map[String(priority)] || map[priority] || (PRIORITY_CONFIG && PRIORITY_CONFIG.defaultJiraPriority) || "Medium";
}

// Extract the first label from a labels array, or empty string
function firstLabel(val) {
  return Array.isArray(val) && val.length > 0 ? val[0] : "";
}

// Normalize a raw Jira field value based on its type spec
function normalizeJiraValue(val, fieldType) {
  if (val === null || val === undefined) return "";
  if (fieldType === "labels") return firstLabel(val);
  if (typeof val === "object" && val.value) {
    return val.value;
  }
  return String(val);
}

// Read a Jira custom field value, normalizing labels/select/plain types
function readJiraField(jiraFields, fieldSpec) {
  const val = jiraFields[fieldSpec.id];
  if (val === null || val === undefined) return "";
  return normalizeJiraValue(val, fieldSpec.type);
}

const TAG_TO_MARK = {
  b: "strong",
  strong: "strong",
  i: "em",
  em: "em",
  u: "underline",
  ins: "underline"
};

const MARK_TAG_TABLE = {
  strong: (t) => `<b>${t}</b>`,
  em: (t) => `<i>${t}</i>`,
  underline: (t) => `<u>${t}</u>`,
  strike: (t) => `<del>${t}</del>`,
  code: (t) => `<code>${t}</code>`
};

function isHexColor(color) {
  return typeof color === "string" && /^#[0-9a-f]{3,8}$/i.test(color);
}

// Marks that carry attributes: links and text colour
function renderAttrMark(text, mark) {
  const attrs = mark.attrs;
  if (!attrs) return text;
  if (mark.type === "link" && attrs.href) {
    return `<a href="${attrs.href}">${text}</a>`;
  }
  if (mark.type === "textColor" && isHexColor(attrs.color)) {
    return `<span style="color:${attrs.color}">${text}</span>`;
  }
  return text;
}

function applyMarkToText(text, mark) {
  if (!mark) return text;
  const markType = typeof mark === "string" ? mark : mark.type;
  const renderer = MARK_TAG_TABLE[markType];
  if (renderer) return renderer(text);
  return renderAttrMark(text, mark);
}

function convertInlineAdfToHtml(inline) {
  if (!inline) return "";
  if (inline.type === "hardBreak") return "<br>";
  if (!inline.text) return "";
  const marks = Array.isArray(inline.marks) ? inline.marks : [];
  return marks.reduce((acc, m) => applyMarkToText(acc, m), inline.text);
}

function renderListBlock(block) {
  const inner = (block.content || []).map(convertBlockAdfToHtml).join("");
  if (block.type === "bulletList") return `<ul>${inner}</ul>`;
  if (block.type === "orderedList") return `<ol>${inner}</ol>`;
  if (block.type === "listItem") return `<li>${inner}</li>`;
  return inner;
}

function renderHeadingBlock(block) {
  const lvl = (block.attrs && block.attrs.level) || 2;
  const inner = (block.content || []).map(convertInlineAdfToHtml).join("");
  return `<h${lvl}><b>${inner}</b></h${lvl}>`;
}

function renderContainerBlock(block) {
  if (block.type === "heading") {
    return renderHeadingBlock(block);
  }
  if (block.type === "blockquote") {
    const inner = (block.content || []).map(convertBlockAdfToHtml).join("");
    return `<blockquote>${inner}</blockquote>`;
  }
  const inner = (block.content || []).map(convertInlineAdfToHtml).join("");
  return inner ? `<p>${inner}</p>` : "";
}

function convertBlockAdfToHtml(block) {
  if (!block) return "";
  if (block.type === "bulletList" || block.type === "orderedList" || block.type === "listItem") {
    return renderListBlock(block);
  }
  return renderContainerBlock(block);
}

function convertInlineWikiMarkup(text) {
  if (!text) return "";
  return text
    .replace(/(^|[^\w*])\*([^*\n]+)\*([^\w*]|$)/g, "$1<b>$2</b>$3")
    .replace(/(^|[^\w_])_([^_\n]+)_([^\w_]|$)/g, "$1<i>$2</i>$3")
    .replace(/(^|[^\w+])\+([^+\n]+)\+([^\w+]|$)/g, "$1<u>$2</u>$3")
    .replace(/(^|[^\w-])-([^-\n]+)-([^\w-]|$)/g, "$1<del>$2</del>$3")
    .replace(/\{\{([^\n]+?)\}\}/g, "<code>$1</code>");
}

function convertWikiLine(line) {
  const trimmed = line.trim();
  const headingMatch = trimmed.match(/^h([1-6])\.\s*(.+)$/);
  if (headingMatch) {
    const lvl = headingMatch[1];
    const content = convertInlineWikiMarkup(headingMatch[2]);
    return `<h${lvl}><b>${content}</b></h${lvl}>`;
  }
  const bqMatch = trimmed.match(/^bq\.\s*(.+)$/);
  if (bqMatch) {
    return `<blockquote>${convertInlineWikiMarkup(bqMatch[1])}</blockquote>`;
  }
  return convertInlineWikiMarkup(line);
}

function convertWikiBlock(block) {
  const trimmed = block.trim();
  if (!trimmed) return "";
  const lines = trimmed.split("\n");
  const converted = lines.map(convertWikiLine);
  if (converted.length === 1 && /^<h[1-6]>|^<blockquote>/.test(converted[0])) {
    return converted[0];
  }
  return `<p>${converted.join("<br>")}</p>`;
}

function convertWikiMarkupToHtml(text) {
  if (!text || typeof text !== "string") return "";
  const blocks = text.replace(/\r\n/g, "\n").split(/\n{2,}/);
  return blocks.map(convertWikiBlock).filter(Boolean).join("");
}

function convertAdfToHtml(adfDoc) {
  if (!adfDoc) return "";
  if (typeof adfDoc === "string") return convertWikiMarkupToHtml(adfDoc);
  if (!Array.isArray(adfDoc.content)) return "";
  return adfDoc.content.map(convertBlockAdfToHtml).filter(Boolean).join("");
}

// ---------- Plain-text helpers (for the Freshdesk "Description" custom field) ----------

const BLOCK_NODE_TYPES = ["paragraph", "heading", "blockquote", "listItem", "codeBlock"];

function leafText(node) {
  if (node.type === "text") return node.text || "";
  return node.type === "hardBreak" ? "\n" : null;
}

function childrenText(node) {
  return Array.isArray(node.content) ? node.content.map(adfNodeToPlainText).join("") : "";
}

function adfNodeToPlainText(node) {
  if (!node || typeof node !== "object") return "";
  const leaf = leafText(node);
  if (leaf !== null) return leaf;
  const inner = childrenText(node);
  return BLOCK_NODE_TYPES.includes(node.type) ? inner + "\n" : inner;
}

// Jira ADF (or wiki string) -> plain text
function convertAdfToPlainText(adfDoc) {
  if (!adfDoc) return "";
  if (typeof adfDoc === "string") return adfDoc.trim();
  return adfNodeToPlainText(adfDoc).replace(/\n{3,}/g, "\n\n").trim();
}

// HTML -> plain text
function htmlToPlainText(html) {
  if (!html) return "";
  const withBreaks = String(html)
    .replace(/<\/(p|div|li|h[1-6])>/gi, "\n")
    .replace(/<br\s*\/?>/gi, "\n");
  return decodeHtmlEntities(withBreaks.replace(/<[^>]+>/g, "")).replace(/\n{3,}/g, "\n\n").trim();
}

function decodeHtmlEntities(str) {
  if (!str) return "";
  return str
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, "\"")
    .replace(/&#39;/gi, "'");
}

function currentColor(activeMarks) {
  const stack = activeMarks.colors || [];
  for (let i = stack.length - 1; i >= 0; i--) {
    if (stack[i]) return stack[i];
  }
  return null;
}

function getActiveMarksList(activeMarks) {
  const marks = [];
  if (activeMarks.strong) marks.push({ type: "strong" });
  if (activeMarks.em) marks.push({ type: "em" });
  if (activeMarks.underline) marks.push({ type: "underline" });
  const color = currentColor(activeMarks);
  if (color) marks.push({ type: "textColor", attrs: { color } });
  return marks;
}

function buildAdfInlineNode(text, activeMarks) {
  const marks = getActiveMarksList(activeMarks);
  const node = { type: "text", text };
  if (marks.length > 0) node.marks = marks;
  return node;
}

function processTextLines(rawText, activeMarks, currentInlines, onFlush) {
  const lines = rawText.split("\n");
  for (let i = 0; i < lines.length; i++) {
    if (i > 0) onFlush();
    const text = decodeHtmlEntities(lines[i]);
    if (text) {
      currentInlines.push(buildAdfInlineNode(text, activeMarks));
    }
  }
}

function findMediaIdInMap(token, mediaMap) {
  if (!mediaMap) return null;
  const srcMatch = token.match(/\ssrc=["']([^"']+)["']/i);
  if (!srcMatch) return null;
  const src = srcMatch[1];
  const byFull = mediaMap[src];
  if (byFull) return byFull;
  const byBase = mediaMap[src.split("?")[0]];
  if (byBase) return byBase;
  const idMatch = token.match(/\s(?:data-id|id)=["']([^"']+)["']/i);
  return idMatch ? mediaMap[idMatch[1]] : null;
}

function handleImageTag(token, mediaMap, onFlush, paragraphs) {
  const mediaId = findMediaIdInMap(token, mediaMap);
  if (!mediaId) return;
  onFlush();
  paragraphs.push({
    type: "mediaSingle",
    attrs: { layout: "center" },
    content: [{ type: "media", attrs: { id: mediaId, type: "file", collection: "" } }]
  });
}

// ---------- Text colour helpers (Freshdesk HTML -> Jira ADF) ----------

const BLOCK_TAGS = ["p", "div", "li"];

function isColorTag(tagName) {
  return tagName === "span" || tagName === "font";
}

function expandHex(hex) {
  return "#" + (hex.length === 3 ? hex.split("").map((c) => c + c).join("") : hex);
}

function rgbToHex(r, g, b) {
  return "#" + [r, g, b].map((n) => Math.min(255, Number(n)).toString(16).padStart(2, "0")).join("");
}

// "#abc" / "#aabbcc" / "rgb(1, 2, 3)" -> "#rrggbb" (null if unsupported)
function colorToHex(value) {
  if (!value) return null;
  const v = String(value).trim().toLowerCase();
  const hex = v.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/);
  if (hex) return expandHex(hex[1]);
  const rgb = v.match(/^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/);
  return rgb ? rgbToHex(rgb[1], rgb[2], rgb[3]) : null;
}

// Read the colour from style="color: ..." or <font color="...">
function extractTagColor(token) {
  const style = token.match(/\sstyle=(["'])(.*?)\1/i);
  const fromStyle = style ? style[2].match(/(?:^|;)\s*color\s*:\s*([^;]+)/i) : null;
  if (fromStyle) return colorToHex(fromStyle[1]);
  const attr = token.match(/\scolor=["']([^"']+)["']/i);
  return attr ? colorToHex(attr[1]) : null;
}

function handleColorTag(token, activeMarks) {
  if (token.startsWith("</")) {
    activeMarks.colors.pop();
  } else {
    activeMarks.colors.push(extractTagColor(token));
  }
}

function handleHtmlTag(token, tagName, activeMarks, onFlush, paragraphs, mediaMap) {
  const isClosing = token.startsWith("</");
  const markType = TAG_TO_MARK[tagName];
  if (markType) {
    activeMarks[markType] = !isClosing;
  } else if (isColorTag(tagName)) {
    handleColorTag(token, activeMarks);
  } else if (BLOCK_TAGS.includes(tagName)) {
    onFlush();
  } else if (tagName === "img") {
    handleImageTag(token, mediaMap, onFlush, paragraphs);
  }
}

function cleanHtmlInput(html) {
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<br\s*[/]?>/gi, "\n");
}

function parseHtmlToAdf(html, mediaMap) {
  if (!html || typeof html !== "string") {
    return { type: "doc", version: 1, content: [] };
  }
  const clean = cleanHtmlInput(html);
  const tagRegex = /(<\/?([a-z0-9]+)[^>]*>|[^<]+)/gi;
  const activeMarks = { strong: false, em: false, underline: false, colors: [] };
  const paragraphs = [];
  let currentInlines = [];

  const flush = () => {
    if (currentInlines.length > 0) {
      paragraphs.push({ type: "paragraph", content: currentInlines });
      currentInlines = [];
    }
  };

  let match;
  while ((match = tagRegex.exec(clean)) !== null) {
    const token = match[0];
    if (token.startsWith("<")) {
      handleHtmlTag(token, (match[2] || "").toLowerCase(), activeMarks, flush, paragraphs, mediaMap);
    } else {
      processTextLines(token, activeMarks, currentInlines, flush);
    }
  }
  flush();

  if (paragraphs.length === 0) {
    paragraphs.push({ type: "paragraph", content: [{ type: "text", text: " " }] });
  }
  return { type: "doc", version: 1, content: paragraphs };
}

function tryJsonParse(val) {
  if (typeof val !== "string") return val;
  try {
    return JSON.parse(val);
  } catch (err) {
    void err;
    return val;
  }
}

function unwrapWebhookBody(obj) {
  if (!obj || typeof obj !== "object") return obj;
  if (obj.body) return tryJsonParse(obj.body);
  if (obj.data && !obj.issue && !obj.comment) return tryJsonParse(obj.data);
  return obj;
}

// Safely parse the Jira webhook body
function parseWebhookPayload(webhookData) {
  const parsed = tryJsonParse(webhookData);
  const unwrapped = unwrapWebhookBody(parsed);
  return unwrapped || {};
}

// Validate webhook payload and return issue, or null if invalid
function validateJiraWebhook(payload) {
  if (!payload || !payload.issue) {
    console.log("No valid issue data in Jira webhook payload");
    return null;
  }
  return payload.issue;
}

// Check if the syncToFreshDesk toggle is "Yes" on the Jira issue
function isSyncEnabled(issue, fieldConfig) {
  const syncField = issue.fields[fieldConfig.syncToFreshDesk.id];
  const syncValue = typeof syncField === "object" && syncField ? syncField.value : syncField;
  console.log("syncToFreshDesk value:", syncValue);
  const normalized = typeof syncValue === "string" ? syncValue.toLowerCase().trim() : "";
  return GENERAL_SETTINGS.syncToggle.yesValues.includes(normalized);
}

// Resolve the Freshdesk ticket ID from Jira issue fields
function getFreshdeskTicketIdFromIssue(issue, fieldConfig) {
  let ticketId = issue.fields[fieldConfig.ticketId.id];
  if (!ticketId && fieldConfig.freshdeskId) {
    ticketId = issue.fields[fieldConfig.freshdeskId];
  }
  if (!ticketId) return null;
  const num = parseInt(ticketId, 10);
  return !isNaN(num) ? String(num) : String(ticketId).trim();
}

// Resolve Freshdesk ticket ID from Jira fields, falling back to search
async function resolveFreshdeskTicketId(issue, fieldConfig, issueKey) {
  const directId = getFreshdeskTicketIdFromIssue(issue, fieldConfig);
  if (directId) return String(directId);

  console.log("No Freshdesk ticket ID in Jira fields, searching by issue key:", issueKey);
  const searchedId = await searchFreshdeskByIssueKey(issueKey);
  if (searchedId) {
    console.log("Found Freshdesk ticket via search:", searchedId);
  }
  return searchedId ? String(searchedId) : null;
}

// Push the Freshdesk update via UpdateTicket template
async function syncToFreshdesk(freshdeskTicketId, updatePayload) {
  console.log("Updating Freshdesk ticket:", freshdeskTicketId, "Payload:", JSON.stringify(updatePayload));
  const response = await $request.invokeTemplate("UpdateTicket", {
    context: { id: freshdeskTicketId },
    body: JSON.stringify(updatePayload)
  });
  console.log("Freshdesk ticket updated successfully! Response:", JSON.stringify(response));
}

function extractErrorDetail(err) {
  if (err && err.response && err.response.data) {
    return JSON.stringify(err.response.data);
  }
  return err ? (err.message || String(err)) : "Unknown error";
}

async function fetchFreshdeskTicketFallback(ticketId) {
  try {
    const url = `https://${FRESHDESK_DOMAIN}/api/v2/tickets/${ticketId}`;
    const res = await axios.get(url, {
      headers: { Authorization: FRESHDESK_AUTH, Accept: "application/json" }
    });
    return res.data;
  } catch (err) {
    const detail = extractErrorDetail(err);
    console.error("Failed to fetch Freshdesk ticket " + ticketId + ":", detail);
    return null;
  }
}

async function fetchFreshdeskTicket(ticketId) {
  if (!ticketId) return null;
  try {
    const res = await $request.invokeTemplate("GetTicket", {
      context: { id: String(ticketId) }
    });
    const data = parseResponseData(res);
    if (data && data.id) return data;
  } catch (templateErr) {
    console.error("GetTicket template error, trying fallback:", templateErr.message || templateErr);
  }
  return fetchFreshdeskTicketFallback(ticketId);
}

async function fetchFreshdeskResponder(responderId) {
  if (!responderId) return null;
  try {
    const url = `https://${FRESHDESK_DOMAIN}/api/v2/agents/${responderId}`;
    const res = await axios.get(url, {
      headers: { Authorization: FRESHDESK_AUTH, Accept: "application/json" }
    });
    return res.data;
  } catch (err) {
    console.log("Failed to fetch Freshdesk responder " + responderId + ":", err.message);
    return null;
  }
}

function requesterNameField() {
  const configured = FD_FIELDS.syncFields && FD_FIELDS.syncFields.contractingAuthority;
  return configured ? String(configured) : "";
}

function responderContactName(agent) {
  const contact = agent && agent.contact;
  const name = contact && contact.name;
  return name ? String(name).trim() : "";
}

async function addRequesterNameField(ticketId, customFields) {
  const fieldName = requesterNameField();
  if (!fieldName) return;
  const ticket = await fetchFreshdeskTicket(ticketId);
  if (!ticket || !ticket.custom_fields || !(fieldName in ticket.custom_fields)) return;
  const agent = await fetchFreshdeskResponder(ticket.responder_id);
  const name = responderContactName(agent);
  if (!name) return;
  customFields[fieldName] = name;
  console.log("Adding responderContactName to Freshdesk ticket", ticketId, "field", fieldName, "value", name);
}

function customFieldsOf(ticket) {
  if (!ticket || !ticket.custom_fields) return {};
  return ticket.custom_fields;
}

function applyFetchedDescription(merged, fetched) {
  const html = fetched.description;
  const text = fetched.description_text;
  if (!html && !text) return;
  merged.description = html || "";
  merged.description_text = text || "";
}

function mergeTicketData(fetched, raw) {
  if (!fetched) return raw || {};
  const mergedCustom = { ...customFieldsOf(fetched) };
  for (const [k, v] of Object.entries(customFieldsOf(raw))) {
    if (hasValue(v) || !hasValue(mergedCustom[k])) {
      mergedCustom[k] = v;
    }
  }
  const merged = {
    ...fetched,
    ...raw,
    custom_fields: mergedCustom
  };
  applyFetchedDescription(merged, fetched);
  return merged;
}

function extractEventTicket(args) {
  if (args && args.data && args.data.ticket) {
    return args.data.ticket;
  }
  return {};
}

function extractEventTicketId(ticket, args) {
  if (ticket && ticket.id) return ticket.id;
  if (args && args.data && args.data.id) return args.data.id;
  return null;
}

async function resolveUpdatedTicket(args) {
  const rawTicket = extractEventTicket(args);
  const ticketId = extractEventTicketId(rawTicket, args);
  if (!ticketId) return { ticket: null, ticketId: null };
  const fetched = await fetchFreshdeskTicket(ticketId);
  const ticket = mergeTicketData(fetched, rawTicket);
  return { ticket, ticketId };
}

// Validate and retrieve project field config from a Jira webhook issue
function getWebhookProjectConfig(issue) {
  const projectKey = issue.fields.project && issue.fields.project.key;
  const fieldConfig = PROJECT_CUSTOM_FIELDS[projectKey];
  if (!fieldConfig) {
    console.log("No field config found for project:", projectKey, "- skipping sync");
    return null;
  }
  if (!isSyncEnabled(issue, fieldConfig)) {
    console.log("Sync to Freshdesk is OFF for issue:", issue.key, "- skipping update");
    return null;
  }
  return fieldConfig;
}

function extractFirstTicketId(data) {
  return data && data.results && data.results[0] ? data.results[0].id : null;
}

// Search Freshdesk for a ticket by Jira issue key (fallback)
async function searchFreshdeskByIssueKey(issueKey) {
  const query = encodeURIComponent(`"${writeFdField("jiraIssueKey")}:'${issueKey}'"`);
  try {
    const res = await $request.invokeTemplate("SearchTickets", { context: { query } });
    const id = extractFirstTicketId(parseResponseData(res));
    if (id) return id;
  } catch (err) {
    console.log("SearchTickets template error:", err.message);
  }
  try {
    const res = await axios.get(`https://${FRESHDESK_DOMAIN}/api/v2/search/tickets?query=${query}`, {
      headers: { Authorization: FRESHDESK_AUTH, Accept: "application/json" }
    });
    const id = extractFirstTicketId(res.data);
    if (id) return id;
  } catch (err) {
    console.log("SearchTickets fallback error:", err.message);
  }
  return null;
}

function hasValue(val) {
  return val !== "" && val !== null && val !== undefined;
}

function normalizeHtml(val) {
  if (val === null || val === undefined) return "";
  return String(val)
    .replace(/<strong>/gi, "<b>")
    .replace(/<\/strong>/gi, "</b>")
    .replace(/<em>/gi, "<i>")
    .replace(/<\/em>/gi, "</i>")
    .replace(/<ins>/gi, "<u>")
    .replace(/<\/ins>/gi, "</u>")
    .trim()
    .toLowerCase();
}

function areValuesEqual(valA, valB) {
  return normalizeHtml(valA) === normalizeHtml(valB);
}

function compareJiraAndFreshdeskField(jiraRawVal, fdRawVal, fieldType) {
  const normJira = normalizeJiraValue(jiraRawVal, fieldType);
  return areValuesEqual(normJira, fdRawVal);
}

function resolveTargetKey(key, current) {
  if (key in current) return key;
  for (const k of Object.keys(current)) {
    if (matchFieldKey(k, key)) return k;
  }
  return key;
}

function buildChangedFreshdeskCustomFields(rawFields, currentCustomFields) {
  const current = currentCustomFields || {};
  const changed = {};
  for (const [key, val] of Object.entries(rawFields)) {
    if (!hasValue(val)) continue;
    const currentVal = findCustomFieldValue(current, key);
    if (!areValuesEqual(val, currentVal)) {
      const targetKey = resolveTargetKey(key, current);
      changed[targetKey] = val;
    }
  }
  return changed;
}

function getFdPriority(priorityObj) {
  if (priorityObj && priorityObj.name) {
    return lookupReversePriority(priorityObj.name);
  }
  return null;
}

function findStatusIdByName(name) {
  if (!name) return null;
  const trimmed = name.trim();
  const map = STATUS_CONFIG.jiraToFreshdesk;
  if (map[trimmed]) {
    return map[trimmed];
  }
  const lower = trimmed.toLowerCase();
  for (const [statusName, id] of Object.entries(map)) {
    if (statusName.toLowerCase() === lower) {
      return id;
    }
  }
  return null;
}

function extractStatusNameFromChangelog(changelog) {
  if (!changelog || !Array.isArray(changelog.items)) return null;
  const item = changelog.items.find((i) => i.field === "status");
  return item && item.toString ? item.toString : null;
}

function getFdStatus(statusObj, changelog) {
  let name = typeof statusObj === "string" ? statusObj : (statusObj && statusObj.name ? statusObj.name : null);
  if (!name) {
    name = extractStatusNameFromChangelog(changelog);
  }
  return findStatusIdByName(name);
}

function applyStandardFieldChanges(updatePayload, jiraFields, currentTicket, changelog) {
  if (jiraFields.summary && !areValuesEqual(jiraFields.summary, currentTicket.subject)) {
    updatePayload.subject = jiraFields.summary;
  }
  const priority = getFdPriority(jiraFields.priority);
  if (priority && priority !== currentTicket.priority) {
    updatePayload.priority = priority;
  }
  const status = getFdStatus(jiraFields.status, changelog);
  if (status && status !== currentTicket.status) {
    updatePayload.status = status;
  }
}

function applyDescriptionChange(updatePayload, jiraFields, currentTicket) {
  const jiraHtml = convertAdfToHtml(jiraFields ? jiraFields.description : null);
  if (!jiraHtml) return;
  const currentText = htmlToPlainText(getTicketDescriptionHtml(currentTicket));
  if (areValuesEqual(htmlToPlainText(jiraHtml), currentText)) return;
  updatePayload.description = jiraHtml;
}

// Build the Freshdesk update payload from Jira issue fields, only including fields that actually changed
function buildFilteredFreshdeskPayload(jiraFields, fieldConfig, currentTicket, changelog) {
  const rawFields = buildRawFreshdeskFields(jiraFields, fieldConfig);

  const changedCustomFields = buildChangedFreshdeskCustomFields(rawFields, currentTicket.custom_fields);
  const updatePayload = {};

  if (Object.keys(changedCustomFields).length > 0) {
    updatePayload.custom_fields = changedCustomFields;
  }
  applyStandardFieldChanges(updatePayload, jiraFields, currentTicket, changelog);
  applyDescriptionChange(updatePayload, jiraFields, currentTicket);
  return updatePayload;
}

function hasAnyChanges(payload) {
  if (payload.subject || payload.priority || payload.status || payload.description) return true;
  return Boolean(payload.custom_fields && Object.keys(payload.custom_fields).length > 0);
}


function buildDescriptionAdf(descHtml) {
  return parseHtmlToAdf(descHtml);
}

function getTicketDescriptionHtml(ticket) {
  if (!ticket) return "";
  return ticket.description || ticket.description_text || "";
}

function buildJiraPayload(ticket, fieldConfig, projectKey) {
  const customFields = ticket.custom_fields || {};
  const ticketId = formatTicketId(fieldConfig.ticketId, ticket.id);
  const summaryText = ticket.subject || "";
  const descText = getTicketDescriptionHtml(ticket);

  const fields = {
    project: {
      key: projectKey
    },
    issuetype: {
      name: JIRA_ISSUE_TYPE || "Task"
    },
    // Project-specific custom fields
    [fieldConfig.ticketId.id]: ticketId,
    ...buildJiraSyncFieldValues(customFields, fieldConfig),
    // Jira single-select dropdown expects { value: "Yes" } (or "Yes" if template handles string)
    [fieldConfig.syncToFreshDesk.id]: { value: GENERAL_SETTINGS.syncToggle.writeYesValue },

    summary: summaryText,
    description: buildDescriptionAdf(descText),
    priority: {
      name: getPriorityName(ticket.priority)
    }
  };
  if (fieldConfig.projectToEscalate) {
    fields[fieldConfig.projectToEscalate] = projectKey;
  }
  if (fieldConfig.freshdeskId) {
    fields[fieldConfig.freshdeskId] = String(ticket.id);
  }

  return { fields };
}

function parseResponseData(response) {
  try {
    const raw = response?.response ?? response;
    return typeof raw === "string" ? JSON.parse(raw) : (raw || {});
  } catch (e) {
    console.log("Could not parse response data:", e.message);
    return {};
  }
}

function extractIssueDetails(response) {
  const data = parseResponseData(response);
  return {
    key: data.key || null,
    id: data.id ? String(data.id) : null
  };
}

function getAttachmentUrl(file) {
  if (!file) return "";
  if (file.attachment_url) return file.attachment_url;
  if (file.url) return file.url;
  if (file.file_url) return file.file_url;
  return "";
}

function isPresignedOrExternalStorage(url) {
  if (typeof url !== "string") return true;
  return /amazonaws\.com|cloudfront\.net|indattachment|attachments|X-Amz-Signature|token=|Signature=|Key-Pair-Id/i.test(url);
}

function getDownloadHeaders(url) {
  if (isPresignedOrExternalStorage(url)) {
    return {};
  }
  if (typeof url === "string" && url.includes(FRESHDESK_DOMAIN)) {
    return { Authorization: FRESHDESK_AUTH };
  }
  return {};
}

function stripS3Auth(options) {
  const host = options.hostname || "";
  if (/amazonaws\.com|cloudfront\.net|indattachment|attachments/i.test(host)) {
    delete options.headers.Authorization;
    delete options.headers.authorization;
  }
}

async function downloadAttachmentBuffer(url) {
  if (!url) return null;
  const fullUrl = url.startsWith("/") ? `https://${FRESHDESK_DOMAIN}${url}` : url;
  try {
    const downloadResponse = await axios.get(fullUrl, {
      responseType: "arraybuffer",
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      maxRedirects: 5,
      beforeRedirect: stripS3Auth,
      headers: getDownloadHeaders(fullUrl)
    });
    if (downloadResponse.status !== 200) {
      console.log("Attachment download failed with status:", downloadResponse.status);
      return null;
    }
    return SafeBuffer.from(downloadResponse.data);
  } catch (err) {
    console.log("Failed to download attachment from " + fullUrl + ":", err.message);
    return null;
  }
}

function resolveContentType(fileName, contentType) {
  if (contentType && contentType !== "application/octet-stream") return contentType;
  if (typeof fileName === "string" && fileName.toLowerCase().endsWith(".pdf")) return "application/pdf";
  return contentType || "application/octet-stream";
}

function buildMultipartBody(fileName, fileBuffer, contentType) {
  const boundary = "----FreshdeskJiraBoundary" + Date.now().toString(16);
  const mime = resolveContentType(fileName, contentType);
  const header = `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${fileName}"\r\nContent-Type: ${mime}\r\n\r\n`;
  const footer = `\r\n--${boundary}--\r\n`;

  const headerBuf = SafeBuffer.from(header, "utf-8");
  const footerBuf = SafeBuffer.from(footer, "utf-8");
  const body = SafeBuffer.concat([headerBuf, fileBuffer, footerBuf]);

  return {
    body,
    contentType: `multipart/form-data; boundary=${boundary}`,
    contentLength: body.length
  };
}

function extractArrayBuffer(buf) {
  if (!buf) {
    return new ArrayBuffer(0);
  }
  if (buf instanceof ArrayBuffer) {
    return buf;
  }
  if (buf.buffer) {
    const start = buf.byteOffset || 0;
    const end = start + (buf.byteLength || buf.length || 0);
    return buf.buffer.slice(start, end);
  }
  return buf;
}

async function postAttachmentToJira(issueKey, fileName, fileBuffer, contentType) {
  const multipart = buildMultipartBody(fileName, fileBuffer, contentType);
  const uploadUrl = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}/attachments`;
  const uploadPayload = extractArrayBuffer(multipart.body);
  const uploadResponse = await axios({
    method: "POST",
    url: uploadUrl,
    data: uploadPayload,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    transformRequest: [(data) => data],
    headers: {
      Authorization: JIRA_AUTH,
      "X-Atlassian-Token": "no-check",
      Accept: "application/json",
      "Content-Type": multipart.contentType,
      "Content-Length": String(multipart.contentLength)
    }
  });
  console.log("Attachment uploaded successfully to Jira:", JSON.stringify(uploadResponse.data));
  return Array.isArray(uploadResponse.data) && uploadResponse.data[0] ? uploadResponse.data[0] : null;
}

function extractUuidFromHeaders(headers) {
  if (!headers) return null;
  const loc = headers.location || headers.Location;
  if (!loc) return null;
  const match = loc.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  return match ? match[0] : null;
}

function isRedirectStatus(status) {
  return status >= 200 && status < 400;
}

async function getJiraMediaId(attachmentId) {
  if (!attachmentId) return null;
  try {
    const url = `https://${JIRA_DOMAIN}/rest/api/3/attachment/content/${attachmentId}`;
    const res = await axios.get(url, {
      headers: { Authorization: JIRA_AUTH },
      maxRedirects: 0,
      validateStatus: isRedirectStatus
    });
    const mediaId = extractUuidFromHeaders(res.headers);
    if (mediaId) {
      console.log(`Media UUID for attachment ${attachmentId}: ${mediaId}`);
    }
    return mediaId;
  } catch (err) {
    void err;
    return null;
  }
}

function saveMediaToMap(mediaMap, mediaId, fileUrl, file) {
  mediaMap[fileUrl] = mediaId;
  mediaMap[fileUrl.split("?")[0]] = mediaId;
  if (file) {
    file.mediaId = mediaId;
    if (file.id) mediaMap[String(file.id)] = mediaId;
    if (file.name) mediaMap[file.name] = mediaId;
  }
}

async function recordUploadedMedia(uploaded, fileUrl, file, mediaMap) {
  const attId = uploaded ? uploaded.id : null;
  if (!attId || !mediaMap) return;
  const mediaId = await getJiraMediaId(attId);
  if (mediaId) {
    saveMediaToMap(mediaMap, mediaId, fileUrl, file);
  }
}

function extractErrorMessage(err) {
  if (err && err.response && err.response.data) {
    return JSON.stringify(err.response.data);
  }
  return err ? err.message : "Unknown error";
}

function isSameAttachment(a, file) {
  if (file.id && a.id === file.id) return true;
  return Boolean(file.name && a.name === file.name);
}

function findAttachmentInList(attachments, file) {
  if (!Array.isArray(attachments)) return "";
  const match = attachments.find((a) => isSameAttachment(a, file) && getAttachmentUrl(a));
  return match ? getAttachmentUrl(match) : "";
}

async function fetchTicketConversations(ticketId) {
  try {
    const url = `https://${FRESHDESK_DOMAIN}/api/v2/tickets/${ticketId}/conversations`;
    const res = await axios.get(url, {
      headers: { Authorization: FRESHDESK_AUTH, Accept: "application/json" }
    });
    return Array.isArray(res.data) ? res.data : [];
  } catch (err) {
    console.log("Failed to fetch conversations:", err.message);
    return [];
  }
}

async function refreshAttachmentUrl(file, ticketId, conversationId) {
  if (!ticketId) return "";
  const list = await fetchTicketConversations(ticketId);
  for (const conv of list) {
    const isTarget = !conversationId || String(conv.id) === String(conversationId);
    if (isTarget) {
      const matchUrl = findAttachmentInList(conv.attachments, file);
      if (matchUrl) return matchUrl;
    }
  }
  return "";
}

async function resolveFileUrl(file, ticketId, conversationId) {
  const direct = getAttachmentUrl(file);
  if (direct) return direct;
  return await refreshAttachmentUrl(file, ticketId, conversationId);
}

async function downloadWithFallback(fileUrl, file, ticketId, conversationId) {
  let buf = await downloadAttachmentBuffer(fileUrl);
  if (!buf && ticketId) {
    console.log("Direct download failed, refreshing attachment URL from Freshdesk API...");
    const freshUrl = await refreshAttachmentUrl(file, ticketId, conversationId);
    if (freshUrl && freshUrl !== fileUrl) {
      buf = await downloadAttachmentBuffer(freshUrl);
    }
  }
  return buf;
}

async function uploadSingleFile(file, issueKey, ticketId, conversationId, mediaMap) {
  const fileUrl = await resolveFileUrl(file, ticketId, conversationId);
  const fileName = (file && file.name) ? file.name : "attachment";
  if (!fileUrl) {
    console.log("No valid attachment URL found for file:", fileName);
    return;
  }
  try {
    console.log("Downloading attachment:", fileUrl);
    const fileBuffer = await downloadWithFallback(fileUrl, file, ticketId, conversationId);
    if (!fileBuffer) {
      console.log("Download returned empty buffer for file:", fileName);
      return;
    }
    console.log("Uploading attachment to Jira:", fileName, "size:", fileBuffer.length);
    const uploaded = await postAttachmentToJira(issueKey, fileName, fileBuffer, file.content_type);
    await recordUploadedMedia(uploaded, fileUrl, file, mediaMap);
  } catch (err) {
    console.log("Error uploading attachment " + fileName + ":", extractErrorMessage(err));
  }
}

function getTransitionNames(t) {
  const toName = t.to && t.to.name ? t.to.name.toLowerCase().trim() : "";
  const name = t.name ? t.name.toLowerCase().trim() : "";
  return { toName, name };
}

function matchTransition(t, targetName) {
  const target = targetName.toLowerCase().trim();
  const { toName, name } = getTransitionNames(t);
  if (toName === target || name === target) return true;
  const aliases = STATUS_CONFIG.aliases[target] || [];
  return aliases.includes(toName) || aliases.includes(name);
}

function findMatchingTransition(transitions, targetStatusName) {
  if (!Array.isArray(transitions)) return null;
  return transitions.find((t) => matchTransition(t, targetStatusName)) || null;
}

async function executeTransition(issueKey, transitionId) {
  const body = JSON.stringify({ transition: { id: String(transitionId) } });
  try {
    const res = await $request.invokeTemplate("TransitionIssue", {
      context: { issueKey },
      body
    });
    console.log("Jira transition executed successfully via template! Response:", JSON.stringify(res));
    return;
  } catch (templateErr) {
    console.log("TransitionIssue template error, trying fallback:", templateErr.message);
  }
  const transitionsUrl = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}/transitions`;
  await axios.post(
    transitionsUrl,
    JSON.parse(body),
    {
      headers: {
        Authorization: JIRA_AUTH,
        "Content-Type": "application/json",
        Accept: "application/json"
      }
    }
  );
}

function extractStatusName(obj) {
  return obj && obj.fields && obj.fields.status ? obj.fields.status.name : null;
}

async function fetchJiraIssueFallback(issueKey) {
  try {
    const url = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}`;
    const res = await axios.get(url, {
      headers: { Authorization: JIRA_AUTH, Accept: "application/json" }
    });
    return res.data;
  } catch (err) {
    const detail = extractErrorDetail(err);
    console.error("Could not fetch Jira issue via fallback " + issueKey + ":", detail);
    return null;
  }
}

async function fetchJiraIssue(issueKey) {
  try {
    const res = await $request.invokeTemplate("GetIssue", {
      context: { issueKey }
    });
    const data = parseResponseData(res);
    if (data && data.fields) return data;
  } catch (templateErr) {
    console.error("GetIssue template error, trying fallback:", templateErr.message || templateErr);
  }
  return fetchJiraIssueFallback(issueKey);
}

async function getJiraIssueStatus(issueKey) {
  const issue = await fetchJiraIssue(issueKey);
  return extractStatusName(issue);
}

function isSameStatus(current, target) {
  if (!current || !target) return false;
  const c = current.trim().toLowerCase();
  const t = target.trim().toLowerCase();
  if (c === t) return true;
  const aliases = STATUS_CONFIG.aliases[t];
  return Boolean(aliases && aliases.includes(c));
}

async function fetchTransitions(issueKey) {
  try {
    const res = await $request.invokeTemplate("GetTransitions", {
      context: { issueKey }
    });
    const data = parseResponseData(res);
    if (Array.isArray(data.transitions)) return data.transitions;
  } catch (templateErr) {
    console.log("GetTransitions template error, trying fallback:", templateErr.message);
  }
  const transitionsUrl = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}/transitions`;
  const res = await axios.get(transitionsUrl, {
    headers: { Authorization: JIRA_AUTH, Accept: "application/json" }
  });
  return res.data && res.data.transitions ? res.data.transitions : [];
}

async function transitionJiraIssue(issueKey, targetStatusName) {
  if (!issueKey || !targetStatusName) return;
  try {
    const current = await getJiraIssueStatus(issueKey);
    if (isSameStatus(current, targetStatusName)) {
      console.log(`Issue ${issueKey} is already in status "${current}" - skipping transition`);
      return;
    }
    const transitions = await fetchTransitions(issueKey);
    const match = findMatchingTransition(transitions, targetStatusName);
    if (!match) {
      console.log(`Transition to "${targetStatusName}" not available for issue ${issueKey}`);
      return;
    }
    console.log(`Transitioning issue ${issueKey} to "${targetStatusName}" (ID ${match.id})`);
    await executeTransition(issueKey, match.id);
    console.log(`Issue ${issueKey} transitioned successfully to "${targetStatusName}"`);
  } catch (err) {
    console.log(`Failed to transition issue ${issueKey} to "${targetStatusName}":`, err.message);
  }
}

async function syncStatusToJira(issueKey, statusId, isCreate = false) {
  const targetStatus = getJiraStatusName(statusId);
  if (!targetStatus) {
    console.log("No Jira status mapping for Freshdesk status ID:", statusId);
    return;
  }
  if (isCreate && GENERAL_SETTINGS.skipTransitionOnCreateStatuses.includes(targetStatus.toLowerCase().trim())) return;
  console.log(`Syncing Freshdesk status ${statusId} -> Jira status "${targetStatus}" for ${issueKey}`);
  await transitionJiraIssue(issueKey, targetStatus);
}

async function uploadAttachments(attachments, issueKey, ticketId, conversationId) {
  const mediaMap = {};
  for (const file of attachments) {
    await uploadSingleFile(file, issueKey, ticketId, conversationId, mediaMap);
  }
  return mediaMap;
}

async function invokeUpdateTicketTemplate(ticketId, updatePayload) {
  try {
    const response = await $request.invokeTemplate("UpdateTicket", {
      context: { id: String(ticketId) },
      body: JSON.stringify(updatePayload)
    });
    console.log("Ticket updated successfully via template! Response:", JSON.stringify(response));
    return true;
  } catch (error) {
    console.log("UpdateTicket template error, trying fallback:", error.message);
    return false;
  }
}

async function sendTicketUpdateAxios(ticketId, updatePayload) {
  try {
    const url = `https://${FRESHDESK_DOMAIN}/api/v2/tickets/${ticketId}`;
    await axios.put(url, updatePayload, {
      headers: { Authorization: FRESHDESK_AUTH, "Content-Type": "application/json", Accept: "application/json" }
    });
    console.log("Ticket updated successfully via fallback axios!");
    return true;
  } catch (err) {
    console.log("Ticket update failed via fallback:", err.message);
    return false;
  }
}

async function sendFreshdeskUpdate(ticketId, updatePayload) {
  const fromTemplate = await invokeUpdateTicketTemplate(ticketId, updatePayload);
  if (fromTemplate) return true;
  return sendTicketUpdateAxios(ticketId, updatePayload);
}

async function updateFreshdeskTicket(ticketId, issueDetails) {
  if (!ticketId || !issueDetails || !issueDetails.key) {
    console.log("Missing ticketId or issueKey for updating ticket");
    return;
  }

  const issueKey = issueDetails.key;
  const issueUrl = `https://${JIRA_DOMAIN}/browse/${issueKey}`;
  const linkFields = buildJiraLinkFields(issueUrl, issueKey, issueDetails.id);
  const customFields = { ...linkFields };
  try {
    await addRequesterNameField(ticketId, customFields);
  } catch (e) {
    void e;
  }

  console.log("Updating Freshdesk ticket:", ticketId, JSON.stringify({ custom_fields: customFields }));
  const success = await sendFreshdeskUpdate(ticketId, { custom_fields: customFields });
  if (!success && Object.keys(linkFields).length > 0) {
    console.log("Retrying Freshdesk ticket update with link fields only:", ticketId);
    await sendFreshdeskUpdate(ticketId, { custom_fields: linkFields });
  }
}

function getStatusFromChanges(changes) {
  if (changes && Array.isArray(changes.status) && changes.status.length > 1) {
    return changes.status[1];
  }
  return null;
}

function resolveTicketStatusId(ticket, data) {
  console.log("resolveTicketStatusId", JSON.stringify({ ticket, data }, null, 2));
  const dataChanges = data ? data.changes : null;
  const ticketChanges = ticket ? ticket.changes : null;
  const fromChange = getStatusFromChanges(dataChanges || ticketChanges);
  if (fromChange) return fromChange;
  return ticket ? ticket.status : null;
}

async function uploadAttachmentsSafely(attachments, issueKey, ticketId, conversationId) {
  if (attachments && attachments.length > 0) {
    return await uploadAttachments(attachments, issueKey, ticketId, conversationId);
  }
  return {};
}

async function sendIssueUpdate(issueKey, payload) {
  try {
    const response = await $request.invokeTemplate("UpdateIssue", {
      context: { issueId: issueKey },
      body: JSON.stringify(payload)
    });
    console.log("Issue Updated successfully via template! Response:", JSON.stringify(response));
    return true;
  } catch (templateError) {
    console.log("UpdateIssue template error, trying fallback:", templateError.message);
  }
  try {
    const updateUrl = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}`;
    await axios.put(updateUrl, payload, {
      headers: {
        Authorization: JIRA_AUTH,
        "Content-Type": "application/json",
        Accept: "application/json"
      }
    });
    console.log("Issue Updated successfully via fallback axios!");
    return true;
  } catch (error) {
    console.log("Issue Update failed via fallback! Error:", error.message);
    return false;
  }
}

async function updateJiraIssueDetails(issueKey, payload, ticketId, attachments) {
  console.log("UpdateIssue Payload:", JSON.stringify(payload));
  if (payload && payload.fields && Object.keys(payload.fields).length > 0) {
    await sendIssueUpdate(issueKey, payload);
  }
  await uploadAttachmentsSafely(attachments, issueKey, ticketId, null);
}

function addCustomFieldDiffs(diff, customFields, currentJiraFields, fieldConfig) {
  for (const item of activeSyncFields(fieldConfig)) {
    const val = getFieldValue(customFields, item.fdName);
    if (!compareJiraAndFreshdeskField(currentJiraFields[item.spec.id], val, item.spec.type)) {
      diff[item.spec.id] = formatFieldValueForJira(item.spec, val);
    }
  }
}

function addPriorityDiff(diff, priorityId, currentPriority) {
  const targetPriorityName = getPriorityName(priorityId);
  const currentPriorityName = currentPriority ? currentPriority.name : "";
  if (!areValuesEqual(targetPriorityName, currentPriorityName)) {
    diff.priority = { name: targetPriorityName };
  }
}

function addTextDiff(diff, key, newVal, currentVal, formatter) {
  if (newVal && !areValuesEqual(newVal, currentVal)) {
    diff[key] = formatter ? formatter(newVal) : newVal;
  }
}

// Compare descriptions as plain text so HTML vs ADF formatting differences don't trigger needless updates
function addDescriptionDiff(diff, descText, currentJiraDescription) {
  const same = areValuesEqual(htmlToPlainText(descText), convertAdfToPlainText(currentJiraDescription));
  if (descText && !same) {
    diff.description = buildDescriptionAdf(descText);
  }
}

function addStandardJiraDiffs(diff, ticket, currentJiraFields, descText) {
  const summaryText = ticket.subject || "";
  addTextDiff(diff, "summary", summaryText, currentJiraFields.summary);
  addDescriptionDiff(diff, descText, currentJiraFields.description);
  addPriorityDiff(diff, ticket.priority, currentJiraFields.priority);
}

function buildJiraDiffFields(ticket, currentJiraFields, fieldConfig) {
  const customFields = ticket.custom_fields || {};
  const diff = {};
  const descText = getTicketDescriptionHtml(ticket);

  addStandardJiraDiffs(diff, ticket, currentJiraFields, descText);
  addCustomFieldDiffs(diff, customFields, currentJiraFields, fieldConfig);
  return diff;
}

function buildJiraUpdateFallbackPayload(ticket, fieldConfig, projectKey) {
  const full = buildJiraPayload(ticket, fieldConfig, projectKey);
  const fields = { ...full.fields };
  delete fields.project;
  delete fields.issuetype;
  return { fields };
}

async function syncStatusToJiraWithCurrent(issueKey, statusId, currentJiraFields) {
  const targetStatus = getJiraStatusName(statusId);
  if (!targetStatus) {
    console.log("No Jira status mapping for Freshdesk status ID:", statusId);
    return;
  }
  const currentStatus = extractStatusName({ fields: currentJiraFields });
  if (isSameStatus(currentStatus, targetStatus)) {
    console.log(`Issue ${issueKey} is already in status "${currentStatus}" - skipping transition`);
    return;
  }
  console.log(`Syncing Freshdesk status ${statusId} -> Jira status "${targetStatus}" for ${issueKey}`);
  await transitionJiraIssue(issueKey, targetStatus);
}

function assignTicketIssueKey(ticket, issueKey) {
  if (ticket && ticket.custom_fields && !getIssueKey(ticket.custom_fields)) {
    const writeKey = writeFdField("jiraIssueKey");
    if (writeKey) {
      ticket.custom_fields[writeKey] = issueKey;
    }
  }
}

function mergeRefreshedCustomFields(ticket, refreshed) {
  if (ticket && refreshed && refreshed.custom_fields) {
    if (!ticket.custom_fields) {
      ticket.custom_fields = {};
    }
    Object.assign(ticket.custom_fields, refreshed.custom_fields);
  }
}

async function retryObtainKey(ticketId, ticket) {
  console.log(`[obtainTicketIssueKey] Jira issue creation in-flight for ticket ${ticketId}. Waiting 2.5s for issue creation/linking...`);
  await delay(2500);
  try {
    const refreshed = await fetchFreshdeskTicket(ticketId);
    if (!refreshed) {
      console.error(`[obtainTicketIssueKey] Failed to fetch refreshed Freshdesk ticket ${ticketId} after wait.`);
    } else {
      mergeRefreshedCustomFields(ticket, refreshed);
      const direct = extractIssueKeyFromCustomFields(refreshed.custom_fields);
      if (direct) {
        console.log(`[obtainTicketIssueKey] Found Jira issue key ${direct} after wait for ticket ${ticketId}`);
        return { issueKey: direct, needsBackfill: false };
      }
    }
    const cf = extractCustomFieldsFromEventOrTicket(ticket, refreshed);
    const projectKey = getProjectKey(cf);
    const searchedKey = await searchJiraByTicketId(ticketId, projectKey);
    if (searchedKey) {
      console.log(`[obtainTicketIssueKey] Found Jira issue key ${searchedKey} via search after wait for ticket ${ticketId}`);
      return { issueKey: searchedKey, needsBackfill: true };
    }
  } catch (err) {
    console.error(`[obtainTicketIssueKey] Error in retryObtainKey for ticket ${ticketId}:`, err.message, err.stack);
  }
  console.error(`[obtainTicketIssueKey] ERROR: Jira issue key not found for ticket ${ticketId} after waiting and searching Jira.`);
  return { issueKey: "", needsBackfill: false };
}

async function obtainTicketIssueKey(ticket, ticketId) {
  try {
    if (!ticketId) {
      console.error("[obtainTicketIssueKey] ERROR: Missing ticketId.");
      return { issueKey: "", needsBackfill: false };
    }
    const direct = extractIssueKeyFromCustomFields(ticket ? ticket.custom_fields : null);
    if (direct) {
      console.log(`[obtainTicketIssueKey] Found Jira issue key ${direct} directly from ticket ${ticketId} custom fields.`);
      return { issueKey: direct, needsBackfill: false };
    }
    const customFields = ticket ? ticket.custom_fields : null;
    const projectKey = getProjectKey(customFields);
    const searchedKey = await searchJiraByTicketId(ticketId, projectKey);
    if (searchedKey) {
      console.log(`[obtainTicketIssueKey] Found Jira issue key ${searchedKey} via Jira search for ticket ${ticketId}`);
      return { issueKey: searchedKey, needsBackfill: true };
    }
    return await retryObtainKey(ticketId, ticket);
  } catch (err) {
    console.error(`[obtainTicketIssueKey] Unexpected error resolving issue key for ticket ${ticketId}:`, err.message, err.stack);
    return { issueKey: "", needsBackfill: false };
  }
}

async function validateUpdateContext(ticket, ticketId) {
  const { issueKey, needsBackfill } = await obtainTicketIssueKey(ticket, ticketId);
  if (!issueKey) {
    console.error(`[validateUpdateContext] ERROR: Cannot process ticket update: Jira issue key could not be resolved for ticket ${ticketId}`);
    return null;
  }
  assignTicketIssueKey(ticket, issueKey);
  const customFields = ticket ? ticket.custom_fields : null;
  const projectKey = getProjectKey(customFields, issueKey);
  const fieldConfig = PROJECT_CUSTOM_FIELDS[projectKey];
  if (!fieldConfig) {
    console.error(`[validateUpdateContext] ERROR: Cannot process ticket update: No project field config found for project "${projectKey}" (ticket ${ticketId}, issueKey: ${issueKey}). Configured projects: ${Object.keys(PROJECT_CUSTOM_FIELDS).join(", ")}`);
    return null;
  }
  return { issueKey, projectKey, fieldConfig, needsBackfill };
}


function determineJiraUpdateFields(ticket, currentJiraIssue, currentJiraFields, fieldConfig, projectKey) {
  console.log("determineJiraUpdateFields", JSON.stringify({ ticket, currentJiraIssue, currentJiraFields, fieldConfig, projectKey }, null, 2));
  if (!currentJiraIssue || !currentJiraIssue.fields) {
    const fallback = buildJiraUpdateFallbackPayload(ticket, fieldConfig, projectKey);
    console.log("fallback", JSON.stringify(fallback, null, 2));
    return fallback.fields;
  }
  const diffFields = buildJiraDiffFields(ticket, currentJiraFields, fieldConfig);
  console.log("diffFields", JSON.stringify(diffFields, null, 2));
  return diffFields;
}

function extractIssueFields(jiraIssue) {
  if (jiraIssue && jiraIssue.fields) {
    return jiraIssue.fields;
  }
  return {};
}

function hasAnyJiraUpdates(fieldsToUpdate, attachments) {
  console.log("hasAnyJiraUpdates", JSON.stringify({ fieldsToUpdate, attachments }, null, 2));
  return Object.keys(fieldsToUpdate).length > 0 || attachments.length > 0;
}

function getProjectFieldConfig(issueKey) {
  const projectKey = getProjectKeyFromIssueKey(issueKey);
  return PROJECT_CUSTOM_FIELDS[projectKey] || null;
}

function hasWebhookIssueFields(issue, fieldConfig) {
  if (!issue || !issue.fields) return false;
  const fields = issue.fields;
  return fields[fieldConfig.syncToFreshDesk.id] !== undefined && fields[fieldConfig.ticketId.id] !== undefined;
}

async function ensureCompleteWebhookIssue(issue) {
  if (!issue || !issue.key) return issue;
  const fieldConfig = getProjectFieldConfig(issue.key);
  if (!fieldConfig) return issue;
  if (hasWebhookIssueFields(issue, fieldConfig)) return issue;
  console.log(`Issue ${issue.key} missing custom fields in webhook, fetching full issue from Jira...`);
  const full = await fetchJiraIssue(issue.key);
  if (full) return full;
  return issue;
}

async function resolveWebhookContext(payload) {
  const rawIssue = validateJiraWebhook(payload);
  if (!rawIssue || !rawIssue.key) return null;
  const issue = await ensureCompleteWebhookIssue(rawIssue);
  const fieldConfig = getWebhookProjectConfig(issue);
  if (!fieldConfig) return null;
  const freshdeskTicketId = await resolveFreshdeskTicketId(issue, fieldConfig, issue.key);
  if (!freshdeskTicketId) return null;
  return { issue, fieldConfig, freshdeskTicketId };
}

function extractIssueKeyFromUrl(url) {
  if (typeof url !== "string") return "";
  const match = url.match(/\/browse\/([A-Za-z0-9]+-\d+)/);
  return match ? match[1].toUpperCase() : "";
}

function extractIssueKeyFromCustomFields(customFields) {
  if (!customFields) return "";
  const key = getIssueKey(customFields);
  if (key) return key;
  const url = readFdField(customFields, "jiraIssueUrl");
  return extractIssueKeyFromUrl(url);
}

function extractFirstIssueKey(responseData) {
  if (responseData && Array.isArray(responseData.issues) && responseData.issues[0]) {
    return responseData.issues[0].key;
  }
  return "";
}

async function invokeJiraSearchTemplate(jql) {
  try {
    const res = await $request.invokeTemplate("SearchJiraIssues", {
      body: JSON.stringify({ jql, maxResults: 1, fields: ["id", "key"] })
    });
    const data = parseResponseData(res);
    const key = extractFirstIssueKey(data);
    if (key) console.log("Found Jira issue key via template:", key);
    return key;
  } catch (templateErr) {
    console.error("SearchJiraIssues template error, trying fallback:", templateErr.message || templateErr);
    return "";
  }
}

async function postJiraSearch(endpoint, jql) {
  try {
    const res = await axios.post(
      `https://${JIRA_DOMAIN}${endpoint}`,
      { jql, maxResults: 1, fields: ["id", "key"] },
      {
        headers: {
          Authorization: JIRA_AUTH,
          "Content-Type": "application/json",
          Accept: "application/json"
        }
      }
    );
    const key = extractFirstIssueKey(res.data);
    if (key) console.log(`Found Jira issue key via fallback (${endpoint}):`, key);
    return key;
  } catch (err) {
    const detail = err.response && err.response.data ? JSON.stringify(err.response.data) : err.message;
    console.error(`Jira search fallback (${endpoint}) error:`, detail);
    return "";
  }
}

async function searchJiraByTicketId(ticketId, projectKey, recentOnly = false) {
  if (!ticketId) return "";
  const jql = buildTicketIdJql(ticketId, projectKey, recentOnly);
  console.log(`Searching Jira for ticket ${ticketId} with JQL: ${jql}`);
  if (!jql) return "";
  const fromTemplate = await invokeJiraSearchTemplate(jql);
  if (fromTemplate) return fromTemplate;
  const fromFallback = await postJiraSearch("/rest/api/3/search/jql", jql);
  if (!fromFallback) {
    console.log(`No Jira issue matched JQL search for ticket ${ticketId}`);
  }
  return fromFallback || "";
}

function extractCustomFieldsFromEventOrTicket(eventTicket, ticket) {
  if (eventTicket && eventTicket.custom_fields) return eventTicket.custom_fields;
  if (ticket && ticket.custom_fields) return ticket.custom_fields;
  return null;
}

function extractTicketCustomFieldKey(ticket) {
  const cf = ticket && ticket.custom_fields ? ticket.custom_fields : null;
  return extractIssueKeyFromCustomFields(cf);
}

async function searchIssueKeyFallback(ticketId, eventTicket, ticket) {
  const cf = extractCustomFieldsFromEventOrTicket(eventTicket, ticket);
  const projectKey = getProjectKey(cf);
  const searchedKey = await searchJiraByTicketId(ticketId, projectKey);
  if (searchedKey) {
    console.log(`[resolveIssueKeyForTicket] Found Jira issue key "${searchedKey}" via Jira search for ticket ${ticketId}`);
    return searchedKey;
  }
  console.error(`[resolveIssueKeyForTicket] ERROR: Could not resolve Jira issue key for ticket ${ticketId}`);
  return "";
}

async function resolveIssueKeyForTicket(ticketId, eventTicket) {
  try {
    const directKey = extractTicketCustomFieldKey(eventTicket);
    if (directKey) return directKey;
    if (!ticketId) {
      console.error("[resolveIssueKeyForTicket] ERROR: Missing ticketId.");
      return "";
    }
    const ticket = await fetchFreshdeskTicket(ticketId);
    const fetchedKey = extractTicketCustomFieldKey(ticket);
    if (fetchedKey) return fetchedKey;
    return await searchIssueKeyFallback(ticketId, eventTicket, ticket);
  } catch (err) {
    console.error(`[resolveIssueKeyForTicket] Error resolving issue key for ticket ${ticketId}:`, err.message, err.stack);
    return "";
  }
}


function getActorDisplayName(actor) {
  if (!actor) return "";
  if (actor.name && actor.email) {
    return `${actor.name} (${actor.email})`;
  }
  if (actor.name) return actor.name;
  return actor.email || "";
}

function formatConversationAuthor(actor, conversation) {
  const actorName = getActorDisplayName(actor);
  if (actorName) return actorName;
  if (conversation && conversation.from_email) {
    return conversation.from_email;
  }
  return TEXT_LABELS.unknownAuthor;
}

function getConversationTypeLabel(conversation) {
  if (conversation && conversation.private) return TEXT_LABELS.privateNote;
  if (conversation && conversation.incoming) return TEXT_LABELS.customerReply;
  return TEXT_LABELS.publicNote;
}


function extractCommentBodyHtml(conversation) {
  if (!conversation) return "";
  return conversation.body || conversation.body_text || "";
}

function buildCommentHeaderPara(conversation, actor) {
  const typeLabel = getConversationTypeLabel(conversation);
  const author = formatConversationAuthor(actor, conversation);
  const content = [{ type: "text", text: `[${TEXT_LABELS.freshdeskCommentPrefix} ${typeLabel} - ${author}]`, marks: [{ type: "strong" }] }];
  if (conversation && conversation.id) {
    content.push({ type: "text", text: " #fd-cid-" + conversation.id + "#" });
  }
  return { type: "paragraph", content: content };
}

const EXTENSION_TYPE_MAP = {
  pdf: "PDF",
  png: "image",
  jpg: "image",
  jpeg: "image",
  gif: "image",
  bmp: "image",
  webp: "image",
  svg: "image",
  doc: "document",
  docx: "document",
  xls: "spreadsheet",
  xlsx: "spreadsheet",
  csv: "spreadsheet"
};

function getFileTypeLabel(fileName) {
  const defaultLabel = (TEXT_LABELS.fileTypes && TEXT_LABELS.fileTypes.default) || "file";
  if (typeof fileName !== "string" || !fileName.includes(".")) return defaultLabel;
  const ext = fileName.split(".").pop().toLowerCase();
  const types = TEXT_LABELS.fileTypes || EXTENSION_TYPE_MAP;
  return types[ext] || defaultLabel;
}

function extractMediaIdFromChild(child) {
  if (child && child.type === "media" && child.attrs) {
    return child.attrs.id || null;
  }
  return null;
}

function isMediaSingleBlock(p) {
  return Boolean(p && p.type === "mediaSingle" && Array.isArray(p.content));
}

function processMediaSingleBlock(p, set) {
  if (!isMediaSingleBlock(p)) return;
  for (const child of p.content) {
    const id = extractMediaIdFromChild(child);
    if (id) set.add(id);
  }
}

function collectEmbeddedMediaIds(paragraphs) {
  const set = new Set();
  if (Array.isArray(paragraphs)) {
    for (const p of paragraphs) {
      processMediaSingleBlock(p, set);
    }
  }
  return set;
}

function resolveMediaIdFromMap(mediaMap, key) {
  return (key && mediaMap && mediaMap[key]) ? mediaMap[key] : null;
}

function resolveMediaIdByUrl(file, mediaMap) {
  const url = getAttachmentUrl(file);
  if (!url) return null;
  const direct = resolveMediaIdFromMap(mediaMap, url);
  if (direct) return direct;
  return resolveMediaIdFromMap(mediaMap, url.split("?")[0]);
}

function resolveMediaIdForAttachment(file, mediaMap) {
  if (!file) return null;
  if (file.mediaId) return file.mediaId;
  const fileIdStr = file.id ? String(file.id) : null;
  const byId = resolveMediaIdFromMap(mediaMap, fileIdStr);
  if (byId) return byId;
  const byName = resolveMediaIdFromMap(mediaMap, file.name);
  if (byName) return byName;
  return resolveMediaIdByUrl(file, mediaMap);
}

function buildAttachmentAdfBlocks(file, mediaId) {
  const fileName = (file && file.name) ? file.name : "attachment";
  const label = getFileTypeLabel(fileName);
  const text = fillTemplate(TEXT_LABELS.attachedFileText, { type: label, name: fileName });
  return [
    {
      type: "paragraph",
      content: [{ type: "text", text }]
    },
    {
      type: "mediaSingle",
      attrs: { layout: "center" },
      content: [
        {
          type: "media",
          attrs: {
            type: "file",
            id: mediaId,
            collection: ""
          }
        }
      ]
    }
  ];
}

function isBlankAdfParagraph(node) {
  if (!node || node.type !== "paragraph") return false;
  if (!Array.isArray(node.content) || node.content.length === 0) return true;
  return node.content.length === 1 && (!node.content[0].text || !node.content[0].text.trim());
}

function filterBlankPlaceholder(content) {
  if (Array.isArray(content) && content.length === 1 && isBlankAdfParagraph(content[0])) {
    return [];
  }
  return content;
}

function collectExtraMediaBlocks(attachments, mediaMap, embeddedIds) {
  const extraBlocks = [];
  for (const file of attachments) {
    const mediaId = resolveMediaIdForAttachment(file, mediaMap);
    if (mediaId && !embeddedIds.has(mediaId)) {
      embeddedIds.add(mediaId);
      extraBlocks.push(...buildAttachmentAdfBlocks(file, mediaId));
    }
  }
  return extraBlocks;
}

function appendPendingAttachments(content, attachments, mediaMap) {
  if (!Array.isArray(attachments) || attachments.length === 0) return content;
  const embeddedIds = collectEmbeddedMediaIds(content);
  const extraBlocks = collectExtraMediaBlocks(attachments, mediaMap, embeddedIds);
  if (extraBlocks.length === 0) return content;
  const baseContent = filterBlankPlaceholder(content);
  return [...baseContent, ...extraBlocks];
}

function buildCommentAdf(conversation, actor, mediaMap, attachments) {
  const headerPara = buildCommentHeaderPara(conversation, actor);
  const bodyHtml = extractCommentBodyHtml(conversation);
  const bodyAdf = parseHtmlToAdf(bodyHtml, mediaMap);
  const finalContent = appendPendingAttachments(bodyAdf.content, attachments, mediaMap);
  return {
    body: {
      type: "doc",
      version: 1,
      content: [headerPara, ...finalContent]
    }
  };
}

function pauseSync(ms) {
  try {
    if (typeof SharedArrayBuffer === "function" && typeof Atomics !== "undefined" && Atomics.wait) {
      const sab = new SharedArrayBuffer(4);
      const int32 = new Int32Array(sab);
      Atomics.wait(int32, 0, 0, ms);
      return;
    }
  } catch (e) {
    void e;
  }
  const end = Date.now() + ms;
  while (Date.now() < end) {
    void 0;
  }
}

function delay(ms) {
  if (typeof setTimeout === "function") {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  pauseSync(ms);
  return Promise.resolve();
}

async function postCommentToJira(issueKey, payload) {
  try {
    const res = await $request.invokeTemplate("AddComment", {
      context: { issueKey },
      body: JSON.stringify(payload)
    });
    console.log("Jira comment added successfully via template! Response:", JSON.stringify(res));
    return true;
  } catch (templateErr) {
    console.log("AddComment template error, trying fallback:", templateErr.message);
  }

  const commentUrl = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}/comment`;
  try {
    await axios.post(
      commentUrl,
      payload,
      {
        headers: {
          Authorization: JIRA_AUTH,
          "Content-Type": "application/json",
          Accept: "application/json"
        }
      }
    );
    console.log("Jira comment added successfully via fallback axios!");
    return true;
  } catch (axiosErr) {
    const detail = axiosErr.response && axiosErr.response.data ? JSON.stringify(axiosErr.response.data) : axiosErr.message;
    console.log(`Fallback axios comment error for ${issueKey}: ${detail}`);
    throw axiosErr;
  }
}

function removeMediaSingleNodes(content) {
  if (!Array.isArray(content)) return [];
  return content.filter((n) => !n || n.type !== "mediaSingle");
}

function buildFallbackCommentPayload(payload) {
  if (!payload || !payload.body || !Array.isArray(payload.body.content)) return payload;
  const filtered = removeMediaSingleNodes(payload.body.content);
  return {
    body: {
      type: "doc",
      version: 1,
      content: filtered
    }
  };
}

async function attemptPostWithRetry(issueKey, payload) {
  const maxAttempts = GENERAL_SETTINGS.commentRetryAttempts || 3;
  const backoffMs = GENERAL_SETTINGS.commentRetryBackoffMs || 2000;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      await postCommentToJira(issueKey, payload);
      return true;
    } catch (err) {
      console.log(`Comment attempt ${attempt} failed (${err.message}) - retrying...`);
      await delay(attempt * backoffMs);
    }
  }
  return false;
}

async function addJiraComment(issueKey, payload) {
  const success = await attemptPostWithRetry(issueKey, payload);
  if (success) return;
  console.log("Media comment failed after retries, falling back to comment without media block");
  const fallback = buildFallbackCommentPayload(payload);
  await postCommentToJira(issueKey, fallback);
}

function parseEventBody(body) {
  try {
    return typeof body === "string" ? JSON.parse(body) : body;
  } catch (e) {
    console.log("Could not parse body:", e.message);
    return null;
  }
}

function extractEventData(args) {
  if (!args) return {};
  if (args.data) return args.data;
  if (args.body) {
    const parsed = parseEventBody(args.body);
    if (parsed && parsed.data) return parsed.data;
    if (parsed) return parsed;
  }
  return args;
}

function getTicketIdFromConversation(conversation) {
  if (!conversation) return null;
  const id = conversation.ticket_id || conversation.notable_id;
  return id ? String(id) : null;
}

function extractConversationTicketId(conversation, data) {
  const fromConv = getTicketIdFromConversation(conversation);
  if (fromConv) return fromConv;
  const fromTicket = data && data.ticket ? data.ticket.id : null;
  const fallback = fromTicket || (data ? data.id : null);
  return fallback ? String(fallback) : null;
}

async function sendCommentToJira(issueKey, conversation, actor, mediaMap, attachments) {
  const payload = buildCommentAdf(conversation, actor, mediaMap, attachments);
  try {
    await addJiraComment(issueKey, payload);
  } catch (err) {
    console.log(`Failed to add comment to Jira issue ${issueKey}:`, err.message);
  }
}

function findConversationInList(list, conversationId) {
  if (!Array.isArray(list) || list.length === 0) return null;
  const match = list.find((c) => String(c.id) === String(conversationId));
  return match || list[list.length - 1];
}

function extractImageAttributes(imgTag) {
  const srcMatch = imgTag.match(/\ssrc=["']([^"']+)["']/i);
  if (!srcMatch || srcMatch[1].startsWith("data:")) return null;
  const src = srcMatch[1];
  const idMatch = imgTag.match(/\s(?:data-id|id)=["']([^"']+)["']/i);
  const rawId = idMatch ? idMatch[1] : "";
  if (rawId === "cursor") return null;
  const cleanId = rawId.replace(/[^a-zA-Z0-9_-]/g, "");
  const name = cleanId ? `signature_${cleanId}.jpg` : "signature_image.jpg";
  return { name, attachment_url: src, content_type: "image/jpeg", is_inline: true, id: cleanId || null };
}

function extractInlineImages(html) {
  if (!html || typeof html !== "string") return [];
  const imgTags = html.match(/<img[^>]+>/gi) || [];
  const results = [];
  for (const tag of imgTags) {
    const attr = extractImageAttributes(tag);
    if (attr) results.push(attr);
  }
  return results;
}

function mergeAttachments(listA, listB) {
  const combined = Array.isArray(listA) ? [...listA] : [];
  const urls = new Set(combined.map((a) => getAttachmentUrl(a)).filter(Boolean));
  for (const b of listB) {
    const bUrl = getAttachmentUrl(b);
    if (bUrl && !urls.has(bUrl)) {
      combined.push(b);
      urls.add(bUrl);
    }
  }
  return combined;
}

function getConversationAttachmentsList(conversation) {
  if (conversation && Array.isArray(conversation.attachments) && conversation.attachments.length > 0) {
    return conversation.attachments;
  }
  return [];
}

async function fetchConversationAttachmentsFallback(conversation, ticketId) {
  if (!ticketId) return [];
  const list = await fetchTicketConversations(ticketId);
  const match = findConversationInList(list, conversation ? conversation.id : null);
  if (match && Array.isArray(match.attachments)) {
    return match.attachments;
  }
  return [];
}

async function resolveConversationAttachments(conversation, ticketId) {
  let regular = getConversationAttachmentsList(conversation);
  if (regular.length === 0) {
    regular = await fetchConversationAttachmentsFallback(conversation, ticketId);
  }
  const inlines = extractInlineImages(conversation ? conversation.body : "");
  return mergeAttachments(regular, inlines);
}

async function createFreshdeskNote(ticketId, notePayload) {
  try {
    const res = await $request.invokeTemplate("CreateNote", {
      context: { ticketId: String(ticketId) },
      body: JSON.stringify(notePayload)
    });
    console.log("Freshdesk public note created successfully via template! Response:", JSON.stringify(res));
    return res;
  } catch (templateErr) {
    console.log("CreateNote template error, trying fallback:", templateErr.message);
  }

  const url = `https://${FRESHDESK_DOMAIN}/api/v2/tickets/${ticketId}/notes`;
  const response = await axios({
    method: "POST",
    url,
    data: notePayload,
    headers: {
      Authorization: FRESHDESK_AUTH,
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });
  console.log("Freshdesk public note created successfully via fallback axios! Note ID:", response.data ? response.data.id : "ok");
  return response.data;
}

function getJiraCommentAuthorName(comment) {
  if (comment && comment.author) {
    return comment.author.displayName || comment.author.emailAddress || TEXT_LABELS.unknownAuthor;
  }
  return TEXT_LABELS.unknownJiraAuthor;
}

function isCommentFromFreshdesk(comment) {
  if (!comment || !comment.body) return false;
  const text = convertAdfToHtml(comment.body);
  const dynamicPrefix = `[${TEXT_LABELS.freshdeskCommentPrefix}`;
  return text.includes(dynamicPrefix) ||
    text.includes("[Freshdesk veřejný komentář") ||
    text.includes("[Freshdesk soukromá poznámka") ||
    text.includes("[Freshdesk ");
}

function conversationBody(conversation) {
  const html = conversation.body || "";
  const text = conversation.body_text || "";
  return html + " " + text;
}

function bodyHasMarker(body, markers) {
  for (const marker of markers) {
    if (body.indexOf(marker) !== -1) return true;
  }
  return false;
}

function isConversationFromJira(conversation) {
  if (!conversation) return false;
  const dynamicPrefix = `[${TEXT_LABELS.jiraCommentPrefix}`;
  return bodyHasMarker(conversationBody(conversation), [
    dynamicPrefix,
    "#jira-cid-",
    "#jira-att-",
    "#jira-description-",
    "[Jira Comment",
    "[Jira Description]"
  ]);
}

async function isCommentAlreadySynced(ticketId, commentId) {
  if (!ticketId || !commentId) return false;
  const list = await fetchTicketConversations(ticketId);
  return list.some((c) => c.body && c.body.includes(`#jira-cid-${commentId}#`));
}

async function fetchJiraComment(issueKey, commentId) {
  if (!issueKey || !commentId) return null;
  try {
    const url = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}/comment/${commentId}`;
    const res = await axios.get(url, {
      headers: { Authorization: JIRA_AUTH, Accept: "application/json" }
    });
    return res.data;
  } catch (err) {
    void err;
    return null;
  }
}

async function resolveJiraCommentBody(comment, issueKey) {
  if (!comment) return null;
  if (comment.id && issueKey) {
    const fetched = await fetchJiraComment(issueKey, comment.id);
    if (fetched && fetched.body) {
      return fetched.body;
    }
  }
  return comment.body;
}

function buildFreshdeskNoteHtml(comment, bodyContent) {
  const author = getJiraCommentAuthorName(comment);
  const bodyHtml = convertAdfToHtml(bodyContent || comment.body);
  const commentId = comment.id ? String(comment.id) : "";
  const tag = commentId ? `<span style="display:none" class="jira-comment-id">#jira-cid-${commentId}#</span>` : "";
  return `<div><p><b>[${TEXT_LABELS.jiraCommentPrefix} - ${author}]</b></p>${bodyHtml}${tag}</div>`;
}

async function shouldSkipJiraComment(ticketId, comment) {
  if (!comment || !comment.body) return true;
  if (isCommentFromFreshdesk(comment)) {
    console.log("Jira comment originated from Freshdesk - skipping sync to Freshdesk to prevent loop");
    return true;
  }
  const commentId = comment.id ? String(comment.id) : "";
  const already = await isCommentAlreadySynced(ticketId, commentId);
  if (already) {
    console.log(`Jira comment ${commentId} already synced to Freshdesk ticket ${ticketId} - skipping`);
    return true;
  }
  return false;
}



// ---------- Jira comment attachments -> Freshdesk note ----------

const FD_MAX_TOTAL_BYTES = 20 * 1024 * 1024; // Freshdesk limit: 20 MB per note

// Check if an ADF node is a collectible media node
function isCollectableMedia(node) {
  return (node.type === "media" || node.type === "mediaInline") &&
    node.attrs && node.attrs.id && node.attrs.type !== "external";
}

// Recursively collect media UUIDs from the comment's ADF body
function collectMediaIdsFromAdf(node, set = new Set()) {
  if (!node || typeof node !== "object") return set;
  if (isCollectableMedia(node)) {
    set.add(node.attrs.id);
  }
  if (Array.isArray(node.content)) {
    node.content.forEach((c) => collectMediaIdsFromAdf(c, set));
  }
  return set;
}

async function fetchJiraIssueAttachments(issueKey) {
  try {
    const res = await axios.get(
      `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}?fields=attachment`,
      { headers: { Authorization: JIRA_AUTH, Accept: "application/json" } }
    );
    return (res.data && res.data.fields && res.data.fields.attachment) || [];
  } catch (err) {
    console.log("Failed to fetch Jira attachments:", err.message);
    return [];
  }
}

// Match the media UUIDs in the comment to the issue's attachments
async function resolveJiraCommentAttachments(issueKey, bodyAdf) {
  const mediaIds = collectMediaIdsFromAdf(bodyAdf);
  if (mediaIds.size === 0) return [];
  const attachments = await fetchJiraIssueAttachments(issueKey);
  const matched = [];
  for (const att of attachments) {
    const mediaId = await getJiraMediaId(att.id);
    if (mediaId && mediaIds.has(mediaId)) matched.push(att);
  }
  console.log(`Comment references ${mediaIds.size} media id(s); matched ${matched.length} attachment(s)`);
  return matched;
}

async function downloadJiraAttachment(att) {
  try {
    const res = await axios.get(
      `https://${JIRA_DOMAIN}/rest/api/3/attachment/content/${att.id}`,
      {
        headers: { Authorization: JIRA_AUTH },
        responseType: "arraybuffer",
        maxRedirects: 5,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        // Don't send Jira Basic auth to the media host after the redirect
        beforeRedirect: (options) => {
          if (options.headers) {
            delete options.headers.Authorization;
            delete options.headers.authorization;
          }
        }
      }
    );
    return SafeBuffer.from(res.data);
  } catch (err) {
    console.log(`Failed to download Jira attachment ${att.filename}:`, err.message);
    return null;
  }
}

// multipart body with text fields + repeated attachments[] parts
function buildNoteMultipart(fields, files) {
  const boundary = "----FDJiraBoundary" + Date.now().toString(16);
  const chunks = [];
  for (const [k, v] of Object.entries(fields)) {
    chunks.push(SafeBuffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`, "utf-8"));
  }
  for (const f of files) {
    const safeName = String(f.name).replace(/"/g, "");
    chunks.push(SafeBuffer.from(
      `--${boundary}\r\nContent-Disposition: form-data; name="attachments[]"; filename="${safeName}"\r\n` +
      `Content-Type: ${resolveContentType(f.name, f.mimeType)}\r\n\r\n`, "utf-8"));
    chunks.push(f.buffer);
    chunks.push(SafeBuffer.from("\r\n", "utf-8"));
  }
  chunks.push(SafeBuffer.from(`--${boundary}--\r\n`, "utf-8"));
  const body = SafeBuffer.concat(chunks);
  return { body, contentType: `multipart/form-data; boundary=${boundary}`, length: body.length };
}

async function createFreshdeskNoteWithFiles(ticketId, html, files) {
  const mp = buildNoteMultipart({ body: html, private: "false" }, files);
  const res = await axios({
    method: "POST",
    url: `https://${FRESHDESK_DOMAIN}/api/v2/tickets/${ticketId}/notes`,
    data: extractArrayBuffer(mp.body),
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    transformRequest: [(d) => d],
    headers: {
      Authorization: FRESHDESK_AUTH,
      Accept: "application/json",
      "Content-Type": mp.contentType,
      "Content-Length": String(mp.length)
    }
  });
  console.log("Freshdesk note with attachments created. Note ID:", res.data && res.data.id);
  return res.data;
}

// Download matched attachments, respecting the 20 MB cap
async function prepareFilesForFreshdesk(atts) {
  const maxBytes = GENERAL_SETTINGS.maxAttachmentMb ? (GENERAL_SETTINGS.maxAttachmentMb * 1024 * 1024) : FD_MAX_TOTAL_BYTES;
  const files = [];
  const skipped = [];
  let total = 0;
  for (const att of atts) {
    if (total + (att.size || 0) > maxBytes) { skipped.push(att.filename); continue; }
    const buffer = await downloadJiraAttachment(att);
    if (!buffer) { skipped.push(att.filename); continue; }
    total += buffer.length;
    files.push({ name: att.filename, mimeType: att.mimeType, buffer });
  }
  return { files, skipped };
}

// Resolve and prepare Jira comment attachments for Freshdesk
async function resolveAndPrepareAttachments(issueKey, bodyContent, commentBody) {
  const atts = await resolveJiraCommentAttachments(issueKey, bodyContent || commentBody);
  if (atts.length === 0) return { files: [], attachHtml: "" };
  const prepared = await prepareFilesForFreshdesk(atts);
  let attachHtml = "";
  const names = prepared.files.map((f) => f.name).join(", ");
  if (names) {
    const text = fillTemplate(TEXT_LABELS.attachedFromJira, { names });
    attachHtml += `<p>${text}</p>`;
  }
  if (prepared.skipped.length) {
    const skippedNames = prepared.skipped.join(", ");
    const text = fillTemplate(TEXT_LABELS.notTransferred, { names: skippedNames });
    attachHtml += `<p>${text}</p>`;
  }
  return { files: prepared.files, attachHtml };
}

// Post a Freshdesk note, falling back to text-only on failure
async function postFreshdeskNote(ticketId, html, files) {
  try {
    if (files.length > 0) {
      await createFreshdeskNoteWithFiles(ticketId, html, files);
    } else {
      await createFreshdeskNote(ticketId, { body: html, private: false });
    }
  } catch (err) {
    const detail = err.response && err.response.data ? JSON.stringify(err.response.data) : err.message;
    console.log("Failed to create Freshdesk note:", detail);
    // last resort: text-only so the comment is never lost
    try { await createFreshdeskNote(ticketId, { body: html, private: false }); } catch (e) { void e; }
  }
}

async function syncJiraCommentToFreshdesk(ticketId, comment, issueKey) {
  const skip = await shouldSkipJiraComment(ticketId, comment);
  if (skip) return;

  const bodyContent = await resolveJiraCommentBody(comment, issueKey);
  const commentId = comment.id ? String(comment.id) : "";
  let html = buildFreshdeskNoteHtml(comment, bodyContent);

  // Pick up files attached inside the Jira comment
  let files = [];
  try {
    const result = await resolveAndPrepareAttachments(issueKey, bodyContent, comment.body);
    files = result.files;
    html += result.attachHtml;
  } catch (err) {
    console.log("Attachment handling failed, continuing with text only:", err.message);
  }

  console.log(`Creating Freshdesk public note on ticket ${ticketId} for Jira comment ${commentId}, files: ${files.length}`);
  await postFreshdeskNote(ticketId, html, files);
}
// async function syncJiraCommentToFreshdesk(ticketId, comment, issueKey) {
//   const skip = await shouldSkipJiraComment(ticketId, comment);
//   if (skip) return;

//   const bodyContent = await resolveJiraCommentBody(comment, issueKey);
//   const commentId = comment.id ? String(comment.id) : "";
//   const html = buildFreshdeskNoteHtml(comment, bodyContent);
//   console.log(`Creating Freshdesk public note on ticket ${ticketId} for Jira comment ${commentId}`);
//   try {
//     await createFreshdeskNote(ticketId, { body: html, private: false });
//   } catch (err) {
//     console.log("Failed to create Freshdesk public note:", err.message);
//   }
// }

function isCommentEventOnly(event) {
  return event === "comment_created" || event === "comment_updated";
}

async function handleWebhookComment(ctx, payload) {
  if (!payload || !payload.comment) return false;
  const issueKey = (ctx && ctx.issue && ctx.issue.key) || null;
  await syncJiraCommentToFreshdesk(ctx.freshdeskTicketId, payload.comment, issueKey);
  return isCommentEventOnly(payload.webhookEvent);
}

async function syncIssueFieldsToFreshdesk(ctx, payload) {
  console.log("Processing Jira update for issue:", ctx.issue.key);
  const currentTicket = await fetchFreshdeskTicket(ctx.freshdeskTicketId);
  if (!currentTicket) {
    console.log("Could not fetch Freshdesk ticket:", ctx.freshdeskTicketId);
    return;
  }

  const updatePayload = buildFilteredFreshdeskPayload(ctx.issue.fields, ctx.fieldConfig, currentTicket, payload.changelog);
  if (!hasAnyChanges(updatePayload)) {
    console.log("Freshdesk ticket", ctx.freshdeskTicketId, "is already in sync with Jira issue", ctx.issue.key, "- skipping update");
    return;
  }

  console.log("Syncing Jira issue", ctx.issue.key, "→ Freshdesk ticket", ctx.freshdeskTicketId, "Payload:", JSON.stringify(updatePayload));
  console.log("syncToFreshdesk", JSON.stringify(updatePayload, null, 2));
  try {
    await syncToFreshdesk(ctx.freshdeskTicketId, updatePayload);
  } catch (error) {
    console.log("Freshdesk ticket update failed! Error:", JSON.stringify(error));
  }
}
function extractWebhookRawData(args) {
  if (!args) return {};
  return args.data !== undefined ? args.data : args;
}

function getWebhookEventName(payload) {
  return (payload && payload.webhookEvent) || "unknown";
}

function isSyncExplicitlyDisabled(issue, fieldConfig) {
  const syncField = issue && issue.fields && issue.fields[fieldConfig.syncToFreshDesk.id];
  const syncVal = typeof syncField === "object" && syncField ? syncField.value : syncField;
  const normalized = typeof syncVal === "string" ? syncVal.toLowerCase().trim() : "";
  return GENERAL_SETTINGS.syncToggle.noValues.includes(normalized);
}

async function isIssueAlreadyLinked(issue, fieldConfig) {
  const existingTicketId = getFreshdeskTicketIdFromIssue(issue, fieldConfig);
  if (existingTicketId) return true;
  const foundTicketId = await searchFreshdeskByIssueKey(issue.key);
  return Boolean(foundTicketId);
}

function getReporterEmail(reporter) {
  return (reporter && reporter.emailAddress) || "";
}

function getEmailFromField(fields, fieldConfig) {
  if (!fields || !fieldConfig.emailFrom) return "";
  const ef = fields[fieldConfig.emailFrom.id];
  return (typeof ef === "string" && ef.includes("@")) ? ef.trim() : "";
}

function resolveRequesterEmail(issue, fieldConfig) {
  const fields = issue && issue.fields;
  const fromReporter = getReporterEmail(fields && fields.reporter);
  if (fromReporter) return fromReporter;
  const fromField = getEmailFromField(fields, fieldConfig);
  if (fromField) return fromField;
  return JIRA_USER_EMAIL || "";
}

function getIssueSummary(fields, issueKey) {
  return (fields && fields.summary) || fillTemplate(TEXT_LABELS.defaultSummary, { key: issueKey });
}

function getIssueDescription(fields, summary) {
  const adf = fields && fields.description;
  return convertAdfToPlainText(adf) || summary;
}

function getIssueStatusId(fields) {
  const name = fields && fields.status && fields.status.name;
  return (name && findStatusIdByName(name)) || GENERAL_SETTINGS.defaultFreshdeskStatusId;
}

function getIssuePriorityId(fields) {
  const name = fields && fields.priority && fields.priority.name;
  const mapped = name ? lookupReversePriority(name) : null;
  return mapped !== null ? mapped : (PRIORITY_CONFIG.defaultFreshdeskPriority || 2);
}

function buildIssueCustomFields(issue, fieldConfig, projectKey) {
  const fields = issue.fields;
  const custom = {
    ...buildRawFreshdeskFields(fields, fieldConfig),
    ...buildJiraLinkFields(`https://${JIRA_DOMAIN}/browse/${issue.key}`, issue.key, issue.id)
  };
  const projName = String(writeFdField("jiraProject") || "").replace(/_\d{6,}$/, "");
  if (projName && projectKey) custom[projName] = projectKey;
  return custom;
}

function buildFreshdeskTicketPayload(issue, fieldConfig, projectKey) {
  const fields = issue.fields;
  const summary = getIssueSummary(fields, issue.key);
  return {
    subject: summary,
    description: getIssueDescription(fields, summary),
    email: resolveRequesterEmail(issue, fieldConfig),
    status: getIssueStatusId(fields),
    priority: getIssuePriorityId(fields),
    custom_fields: buildIssueCustomFields(issue, fieldConfig, projectKey)
  };
}

async function createTicketInFreshdesk(ticketPayload) {
  try {
    const res = await $request.invokeTemplate("CreateTicket", { body: JSON.stringify(ticketPayload) });
    const data = parseResponseData(res);
    return data && data.id;
  } catch (err) {
    console.log("CreateTicket template failed, trying fallback axios:", err.message);
  }
  try {
    const url = `https://${FRESHDESK_DOMAIN}/api/v2/tickets`;
    const fallbackRes = await axios.post(url, ticketPayload, {
      headers: { Authorization: FRESHDESK_AUTH, "Content-Type": "application/json" }
    });
    return fallbackRes.data && fallbackRes.data.id;
  } catch (fallbackErr) {
    console.log("Failed to create Freshdesk ticket via fallback:", fallbackErr.message);
    return null;
  }
}

async function linkTicketIdToJira(issueKey, fieldConfig, ticketId) {
  const jiraFields = { [fieldConfig.ticketId.id]: String(ticketId) };
  if (fieldConfig.freshdeskId) {
    jiraFields[fieldConfig.freshdeskId] = String(ticketId);
  }
  if (fieldConfig.syncToFreshDesk) {
    jiraFields[fieldConfig.syncToFreshDesk.id] = { value: GENERAL_SETTINGS.syncToggle.writeYesValue };
  }
  await sendIssueUpdate(issueKey, { fields: jiraFields });
}

function getIssueProjectConfig(issue) {
  const fields = issue && issue.fields;
  const key = (fields && fields.project && fields.project.key) || getProjectKeyFromIssueKey(issue.key);
  return { projectKey: key, fieldConfig: PROJECT_CUSTOM_FIELDS[key] };
}

function isCreationAllowed(issue, fieldConfig) {
  if (!fieldConfig) return false;
  return !isSyncExplicitlyDisabled(issue, fieldConfig);
}

async function handleJiraIssueCreated(payload) {
  const rawIssue = validateJiraWebhook(payload);
  if (!rawIssue || !rawIssue.key) return;
  const fetched = await fetchJiraIssue(rawIssue.key);
  const issue = fetched || await ensureCompleteWebhookIssue(rawIssue);
  const { projectKey, fieldConfig } = getIssueProjectConfig(issue);
  if (!isCreationAllowed(issue, fieldConfig)) return;
  if (await isIssueAlreadyLinked(issue, fieldConfig)) {
    console.log("Jira issue", issue.key, "was created from Freshdesk - skipping sync back to Freshdesk");
    return;
  }

  const ticketPayload = buildFreshdeskTicketPayload(issue, fieldConfig, projectKey);
  console.log("Creating Freshdesk ticket for Jira issue", issue.key);
  const createdTicketId = await createTicketInFreshdesk(ticketPayload);
  if (createdTicketId) {
    await linkTicketIdToJira(issue.key, fieldConfig, createdTicketId);
  }
}

function extractCreateTicketData(args) {
  const data = args && args.data;
  return (data && data.ticket) || {};
}

async function handleCreatedIssueResponse(response, ticketId, attachments, status) {
  console.log("Issue Created successfully! Response:", JSON.stringify(response));
  const issueDetails = extractIssueDetails(response);
  if (!issueDetails.key) return;
  await updateFreshdeskTicket(ticketId, issueDetails);
  if (attachments.length > 0) {
    await uploadAttachmentsSafely(attachments, issueDetails.key, ticketId, null);
  }
  await syncStatusToJira(issueDetails.key, status, true);
}

const jiraCreateSlots = new Set();

function takeJiraCreateSlot(ticketId) {
  const id = String(ticketId || "");
  if (!id || jiraCreateSlots.has(id)) return false;
  jiraCreateSlots.add(id);
  return true;
}

const HISTORY_BATCH = 5;

function fileLabel(file) {
  if (!file) return "";
  return String(file.filename || file.name || "").toLowerCase();
}

function listedNames(groups) {
  const names = {};
  for (const group of groups) {
    for (const file of group || []) {
      const label = fileLabel(file);
      if (label) names[label] = true;
    }
  }
  return names;
}

function fileIsMissing(file, known) {
  const label = fileLabel(file);
  return Boolean(label) && !known[label];
}

function jiraCommentPlain(comment) {
  if (!comment || !comment.body) return "";
  return convertAdfToPlainText(comment.body) || convertAdfToHtml(comment.body) || "";
}

async function fetchJiraComments(issueKey) {
  if (!issueKey) return [];
  try {
    const url = `https://${JIRA_DOMAIN}/rest/api/3/issue/${issueKey}/comment?maxResults=100`;
    const res = await axios.get(url, {
      headers: { Authorization: JIRA_AUTH, Accept: "application/json" }
    });
    const comments = res.data && res.data.comments;
    return Array.isArray(comments) ? comments : [];
  } catch (err) {
    console.log("Failed to fetch Jira comments for", issueKey, err.message);
    return [];
  }
}

function jiraCommentOnFreshdesk(comment, conversations) {
  const id = comment && comment.id ? String(comment.id) : "";
  if (!id) return true;
  const marker = "#jira-cid-" + id + "#";
  return (conversations || []).some((item) => (item.body || "").indexOf(marker) !== -1);
}

function shouldCopyJiraComment(comment, conversations) {
  if (!comment || isCommentFromFreshdesk(comment)) return false;
  return !jiraCommentOnFreshdesk(comment, conversations);
}

async function copyMissingJiraComments(issueKey, ticketId, comments, conversations) {
  let copied = 0;
  for (const comment of comments || []) {
    if (copied >= HISTORY_BATCH) break;
    if (!shouldCopyJiraComment(comment, conversations)) continue;
    await syncJiraCommentToFreshdesk(ticketId, comment, issueKey);
    copied += 1;
  }
}

function freshdeskCopyMatches(comment, marker, plain) {
  const text = jiraCommentPlain(comment);
  if (marker && text.indexOf(marker) !== -1) return true;
  if (!plain || !isCommentFromFreshdesk(comment)) return false;
  return text.indexOf(plain) !== -1;
}

function conversationOnJira(conversation, jiraComments) {
  if (!conversation || isConversationFromJira(conversation)) return true;
  const marker = "#fd-cid-" + String(conversation.id || "") + "#";
  const plain = htmlToPlainText(extractCommentBodyHtml(conversation));
  return (jiraComments || []).some((comment) => freshdeskCopyMatches(comment, marker, plain));
}

async function copyMissingFreshdeskConversations(issueKey, conversations, jiraComments) {
  let copied = 0;
  for (const conversation of conversations || []) {
    if (copied >= HISTORY_BATCH) break;
    if (conversationOnJira(conversation, jiraComments)) continue;
    const files = Array.isArray(conversation.attachments) ? conversation.attachments : [];
    await sendCommentToJira(issueKey, conversation, null, {}, files);
    copied += 1;
  }
}

async function copyFreshdeskFilesToJira(issueKey, ticket, jiraFiles) {
  const known = listedNames([jiraFiles]);
  const source = ticket && ticket.attachments;
  const missing = (source || []).filter((file) => fileIsMissing(file, known)).slice(0, HISTORY_BATCH);
  if (missing.length === 0) return;
  console.log("Copying missing Freshdesk files to Jira", issueKey, missing.length);
  await uploadAttachmentsSafely(missing, issueKey, ticket.id, null);
}

async function copyJiraFilesToFreshdesk(ticketId, ticket, conversations, jiraFiles) {
  const groups = [ticket && ticket.attachments];
  for (const conversation of conversations || []) groups.push(conversation.attachments);
  const known = listedNames(groups);
  const missing = (jiraFiles || []).filter((file) => fileIsMissing(file, known)).slice(0, HISTORY_BATCH);
  if (missing.length === 0) return;
  const prepared = await prepareFilesForFreshdesk(missing);
  if (!prepared.files.length) return;
  const marker = missing.map((file) => file.id).filter(Boolean).join("-");
  const html = "<div><p><b>[Jira attachments]</b></p><span style=\"display:none\">#jira-att-" + marker + "#</span></div>";
  console.log("Copying missing Jira files to Freshdesk ticket", ticketId, prepared.files.length);
  await postFreshdeskNote(ticketId, html, prepared.files);
}

async function runHistorySync(issueKey, ticketId) {
  const comments = await fetchJiraComments(issueKey);
  const conversations = await fetchTicketConversations(ticketId);
  const ticket = await fetchFreshdeskTicket(ticketId);
  const issue = await fetchJiraIssue(issueKey);
  const jiraFiles = issue && issue.fields ? issue.fields.attachment : [];
  await copyMissingJiraComments(issueKey, ticketId, comments, conversations);
  await copyMissingFreshdeskConversations(issueKey, conversations, comments);
  await copyFreshdeskFilesToJira(issueKey, ticket, jiraFiles);
  await copyJiraFilesToFreshdesk(ticketId, ticket, conversations, jiraFiles);
}

async function syncMissingHistory(issueKey, ticketId) {
  if (!issueKey || !ticketId) return;
  console.log("Syncing missing history for Jira", issueKey, "Freshdesk ticket", ticketId);
  try {
    await runHistorySync(issueKey, ticketId);
  } catch (err) {
    console.log("Missing history sync failed:", err.message);
  }
}

async function syncHistoryWhenEnabled(issue, fieldConfig, issueKey, ticketId) {
  if (!issue || !issue.fields || !isSyncEnabled(issue, fieldConfig)) {
    console.log("Sync to Freshdesk is OFF for issue:", issueKey, "- skipping missing history");
    return;
  }
  await syncMissingHistory(issueKey, ticketId);
}

async function createIssueAfterSlot(ticket, fieldConfig, projectKey) {
  const foundKey = await searchJiraByTicketId(ticket.id, projectKey, true);
  if (foundKey) {
    console.log(`Issue ${foundKey} already exists for Freshdesk ticket ${ticket.id} - skipping duplicate create`);
    await updateFreshdeskTicket(ticket.id, { key: foundKey, id: null });
    return;
  }
  const payload = buildJiraPayload(ticket, fieldConfig, projectKey);
  const attachments = ticket.attachments || [];
  try {
    const response = await $request.invokeTemplate("CreateIssue", { body: JSON.stringify(payload) });
    await handleCreatedIssueResponse(response, ticket.id, attachments, ticket.status);
  } catch (error) {
    console.log("Issue Created failed! Error:", JSON.stringify(error));
    jiraCreateSlots.delete(String(ticket.id || ""));
  }
}

async function createIssueForNewTicket(ticket, customFields) {
  const projectKey = getProjectKey(customFields);
  const fieldConfig = PROJECT_CUSTOM_FIELDS[projectKey];
  if (!fieldConfig) return;
  if (!takeJiraCreateSlot(ticket.id)) {
    console.log("Jira create already started for Freshdesk ticket", ticket.id, "- skipping duplicate");
    return;
  }
  await createIssueAfterSlot(ticket, fieldConfig, projectKey);
}

async function backfillTicketLinkIfNeeded(ticketId, ctx) {
  if (ctx && ctx.needsBackfill && ctx.issueKey) {
    console.log(`Backfilling missing Jira issue key ${ctx.issueKey} to Freshdesk ticket ${ticketId}`);
    await updateFreshdeskTicket(ticketId, { key: ctx.issueKey, id: null });
  }
}

async function executeTicketFieldSync(ticket, ticketId, ctx, currentJiraIssue, currentJiraFields) {
  const attachments = ticket ? (ticket.attachments || []) : [];
  const fieldsToUpdate = determineJiraUpdateFields(ticket, currentJiraIssue, currentJiraFields, ctx.fieldConfig, ctx.projectKey);

  if (!hasAnyJiraUpdates(fieldsToUpdate, attachments)) {
    console.log("Jira issue", ctx.issueKey, "is already in sync with Freshdesk ticket", ticketId);
    await syncHistoryWhenEnabled(currentJiraIssue, ctx.fieldConfig, ctx.issueKey, ticketId);
    return;
  }

  console.log("Updating Jira issue", ctx.issueKey, "with fields:", JSON.stringify(fieldsToUpdate));
  await updateJiraIssueDetails(ctx.issueKey, { fields: fieldsToUpdate }, ticketId, attachments);
  await syncHistoryWhenEnabled(currentJiraIssue, ctx.fieldConfig, ctx.issueKey, ticketId);
}

exports = {

  onTicketCreateHandler: async function (args) {
    initCredentials(args);
    const ticket = extractCreateTicketData(args);
    const customFields = ticket.custom_fields || {};
    if (getIssueKey(customFields)) {
      console.log(`Ticket ${ticket.id} already has Jira issue key, skipping Jira creation.`);
      return;
    }
    await createIssueForNewTicket(ticket, customFields);
  },
  onTicketUpdateHandler: async function (args) {
    initCredentials(args);
    //console.log("onTicketUpdateHandler",JSON.stringify(args,null,2));
    const { ticket, ticketId } = await resolveUpdatedTicket(args);
    const ctx = await validateUpdateContext(ticket, ticketId);
    if (!ctx) {
      console.log(`Cannot process ticket update for ticket ${ticketId}: invalid or incomplete update context`);
      return;
    }

    await backfillTicketLinkIfNeeded(ticketId, ctx);

    const currentJiraIssue = await fetchJiraIssue(ctx.issueKey);
    console.log("currentJiraIssue", JSON.stringify(currentJiraIssue, null, 2));
    const currentJiraFields = extractIssueFields(currentJiraIssue);
    console.log("currentJiraFields", JSON.stringify(currentJiraFields, null, 2));
    const statusId = resolveTicketStatusId(ticket, args ? args.data : null);
    console.log("statusIdsdsd", ctx.issueKey, statusId, JSON.stringify(currentJiraFields, null, 2));
    await syncStatusToJiraWithCurrent(ctx.issueKey, statusId, currentJiraFields);

    await executeTicketFieldSync(ticket, ticketId, ctx, currentJiraIssue, currentJiraFields);
  },

  onConversationCreateHandler: async function (args) {
    initCredentials(args);
    const data = extractEventData(args);
    const conversation = data.conversation || {};
    const ticketId = extractConversationTicketId(conversation, data);

    console.log(`onConversationCreate received for ticket ${ticketId}, conversation ${conversation.id}`);

    if (isConversationFromJira(conversation)) {
      console.log(`Conversation ${conversation.id} originated from Jira sync - skipping Jira comment upload to prevent loop`);
      return;
    }

    const issueKey = await resolveIssueKeyForTicket(ticketId, data.ticket);
    if (!issueKey) {
      console.log(`Cannot process conversation: No Jira issue key found for Freshdesk ticket ${ticketId}`);
      return;
    }

    console.log(`Syncing conversation ${conversation.id} to Jira issue ${issueKey}`);
    const attachments = await resolveConversationAttachments(conversation, ticketId);
    let mediaMap = {};
    if (Array.isArray(attachments) && attachments.length > 0) {
      console.log(`Uploading ${attachments.length} attachment(s) separately to Jira task ${issueKey}`);
      mediaMap = await uploadAttachmentsSafely(attachments, issueKey, ticketId, conversation.id);
      await delay(GENERAL_SETTINGS.attachmentDelayMs);
    }

    await sendCommentToJira(issueKey, conversation, data.actor, mediaMap, attachments);
  },

  // ─────────────────────────────────────────────────────────────────────────
  // Jira → Freshdesk sync via Jira Webhook (onExternalEvent)
  // ─────────────────────────────────────────────────────────────────────────
  onExternalEventHandler: async function (args) {
    initCredentials(args);
    console.log("onExternalEventHandler", JSON.stringify(args, null, 2));
    let payload;
    try {
      payload = parseWebhookPayload(extractWebhookRawData(args));
    } catch (e) {
      console.log("Failed to parse Jira webhook payload:", e.message);
      return;
    }
    const eventName = getWebhookEventName(payload);
    console.log("Jira webhook received. Event:", eventName);
    console.log("Jira webhook payload", JSON.stringify(payload, null, 2));

    if (eventName === "jira:issue_created") {
      await handleJiraIssueCreated(payload);
      return;
    }

    const ctx = await resolveWebhookContext(payload);
    if (!ctx) return;

    const isCommentOnly = await handleWebhookComment(ctx, payload);
    if (!isCommentOnly) {
      await syncIssueFieldsToFreshdesk(ctx, payload);
    }
    await syncMissingHistory(ctx.issue.key, ctx.freshdeskTicketId);
  },

  onAppInstallHandler: async function (args) {
    initCredentials(args);
    console.info('onAppInstallHandler invoked with following data: \n', args);
    try {
      const targetUrl = await generateTargetUrl();
      console.log("Jira webhook target URL generated:", targetUrl);
      console.log("Register this URL in Jira: Settings → System → Webhooks");
      renderData();
    } catch (error) {
      console.log("Failed to generate target URL:", JSON.stringify(error));
      renderData({ message: "Failed to generate webhook target URL" });
    }
  },
  onAppUninstallHandler: function (args) {
    console.log('onAppUninstalHandler invoked with following data: \n', args);
    renderData();
  }

};

if (typeof module !== "undefined" && module.exports) {
  module.exports = exports;
}
